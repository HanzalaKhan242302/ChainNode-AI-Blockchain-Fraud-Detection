"""
Risk Scorer - the public entry point for fraud detection.

Combines:
  Layer 1: RuleEngine   - hard rejects (signature, blacklist, burst, cap)
  Layer 2: MLFraudModel - Isolation Forest anomaly score

Decision policy:
  - If any rule fires      → REJECT (risk = 100)
  - Else compute ML score
      * score >= HIGH_RISK_THRESHOLD → REJECT + flag sender
      * score >= MED_RISK_THRESHOLD  → ACCEPT but mark for review
      * else                         → ACCEPT clean

This single class is what core/blockchain.py asks before accepting a tx.
"""

from .rules import RuleEngine
from .ml_model import MLFraudModel
from .trust_engine import TrustEngine


HIGH_RISK_THRESHOLD = 75.0   # auto-reject
MED_RISK_THRESHOLD  = 40.0   # accept but flag for review


class RiskScorer:
    def __init__(self, persistence=None):
        self.rules = RuleEngine(persistence=persistence)
        self.ml = MLFraudModel()
        self.trust = TrustEngine(persistence=persistence)
        self.persistence = persistence
        # Stats for UI
        self.total_evaluated = 0
        self.total_rejected = 0
        self.total_flagged = 0

    def evaluate(self, tx, blockchain) -> tuple[bool, str, float]:
        """
        Run both layers. Returns (accepted, reason, risk_score).
        """
        self.total_evaluated += 1

        # Layer 1
        passed, reason = self.rules.check(tx, blockchain)
        if not passed:
            self.total_rejected += 1
            return False, reason, 100.0

        # Layer 2: ML anomaly score
        ml_risk = self.ml.score(tx, blockchain)

        # Layer 3: wallet-level trust + live behaviour
        # Final Risk = ML Risk + Trust Penalty + Behaviour Score
        trust = 100.0
        if tx.sender:
            trust = self.trust.get_trust(tx.sender, blockchain)
        trust_penalty = (100.0 - trust) * 0.3        # low trust => up to +30
        behaviour = self.trust.behaviour_score(tx, blockchain)  # up to +25

        risk = round(min(100.0, ml_risk + trust_penalty + behaviour), 2)

        # Expose the breakdown on the tx for storage / explainability
        tx.ml_risk = round(ml_risk, 2)
        tx.trust_penalty = round(trust_penalty, 2)
        tx.behaviour_score = round(behaviour, 2)
        tx.sender_trust = round(trust, 1)

        if risk >= HIGH_RISK_THRESHOLD:
            self.total_rejected += 1
            if self.persistence and tx.sender:
                self.persistence.flag_wallet(
                    tx.sender, f"high combined risk ({risk})"
                )
            return False, f"high combined risk ({risk})", risk

        if risk >= MED_RISK_THRESHOLD:
            self.total_flagged += 1
            # Attach score onto tx for storage
            tx.risk_score = risk
            return True, f"flagged for review ({risk})", risk

        tx.risk_score = risk
        return True, "ok", risk

    def on_block_mined(self, blockchain):
        """Hook called by blockchain after a block is added - keeps ML fresh."""
        self.ml.maybe_retrain(blockchain)
        # Chain changed => cached trust scores are stale.
        self.trust.invalidate()

    def wallet_report(self, pk, blockchain) -> dict:
        """Trust breakdown for a wallet - used by wallet detail / analytics."""
        return self.trust.report(pk, blockchain)

    def stats(self) -> dict:
        return {
            "total_evaluated": self.total_evaluated,
            "total_rejected": self.total_rejected,
            "total_flagged": self.total_flagged,
            "ml_trained": self.ml.trained,
            "ml_training_size": self.ml.last_train_size,
        }

    def explain(self, tx, blockchain) -> dict:
        """Public interface for ML feature breakdown."""
        return self.ml.explain(tx, blockchain)
