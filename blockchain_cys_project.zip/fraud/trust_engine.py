"""
Wallet Trust Engine - Layer 3 of the fraud system (research novelty).

Every wallet carries a dynamic reputation score in the range 0-100.
Unlike the per-transaction ML risk score (which judges a single transfer in
isolation), the trust score is a *wallet-level* memory of behaviour built by
replaying the whole chain plus the node's flag list.

Design goals:
  - Deterministic: same chain + same flags always yields the same score,
    so results are reproducible for the report / demo.
  - Explainable: every point gained or lost is attributable to a component.
  - Bounded: always clamped to [0, 100].

Scoring model
-------------
Start at 100 (full trust) and apply:

  Penalties (bad behaviour):
    - each HIGH-risk (>=75) tx the wallet took part in ...... -30
    - each MEDIUM-risk (40-75) tx it took part in ........... -10
    - wallet is blacklisted / flagged on this node ......... -45

  Recovery (sustained good behaviour, offsets penalties only):
    - clean confirmed transactions and mined blocks let a wallet
      earn back trust it lost, but can never push it above 100.

Classification bands (per the project spec):
    90-100  Trusted
    70-89   Normal
    40-69   Under Review
    0-39    Blacklisted

The final risk of a transaction combines the ML risk, the sender's trust,
and a live behaviour score (see fraud/risk_scorer.py):

    Final Risk = ML Risk + Trust Penalty + Behaviour Score
"""

HIGH_RISK = 75.0
MED_RISK = 40.0


def classify(trust: float) -> str:
    if trust >= 90:
        return "Trusted"
    if trust >= 70:
        return "Normal"
    if trust >= 40:
        return "Under Review"
    return "Blacklisted"


class TrustEngine:
    """Computes and caches wallet trust scores from chain history."""

    def __init__(self, persistence=None):
        self.persistence = persistence
        # pubkey -> report dict cache; cleared whenever the chain changes.
        self._cache: dict[str, dict] = {}

    # ---------- Cache control ----------

    def invalidate(self):
        """Called after a block is mined / chain replaced."""
        self._cache.clear()

    # ---------- Core computation ----------

    def report(self, pk: str, blockchain) -> dict:
        """
        Full trust breakdown for a wallet public key.
        Returns dict: trust, classification, blacklisted, and the raw
        behavioural counters used to derive the score.
        """
        if not pk:
            return self._empty_report()
        if pk in self._cache:
            return self._cache[pk]

        sent_count = 0
        recv_count = 0
        mined_count = 0
        high_risk = 0
        med_risk = 0

        for block in blockchain.chain:
            for tx in block.transactions:
                involves = (tx.sender == pk) or (tx.receiver == pk)
                if not involves:
                    continue
                if not tx.sender and tx.receiver == pk:
                    mined_count += 1          # coinbase / mining reward
                elif tx.sender == pk:
                    sent_count += 1
                elif tx.receiver == pk:
                    recv_count += 1
                r = getattr(tx, "risk_score", 0) or 0
                if r >= HIGH_RISK:
                    high_risk += 1
                elif r >= MED_RISK:
                    med_risk += 1

        total_txs = sent_count + recv_count
        clean_txs = max(0, total_txs - high_risk - med_risk)

        flagged = bool(
            self.persistence and self.persistence.is_flagged(pk)
        )

        # --- Penalties ---
        penalty = high_risk * 30 + med_risk * 10 + (45 if flagged else 0)
        trust = 100.0 - penalty

        # --- Recovery (only offsets penalties, never exceeds 100) ---
        clean_activity = clean_txs + mined_count
        recovery = min(clean_activity * 1.5, max(0.0, penalty) * 0.5)
        trust += recovery

        trust = round(max(0.0, min(100.0, trust)), 1)

        blacklisted = flagged or trust < 40
        # A flagged wallet is treated as Blacklisted regardless of its
        # residual numeric score, so the label the user sees is consistent.
        classification = "Blacklisted" if blacklisted else classify(trust)

        report = {
            "trust": trust,
            "classification": classification,
            "blacklisted": blacklisted,
            "sent_count": sent_count,
            "recv_count": recv_count,
            "mined_count": mined_count,
            "total_txs": total_txs,
            "high_risk_txs": high_risk,
            "med_risk_txs": med_risk,
            "clean_txs": clean_txs,
            "penalty": round(penalty, 1),
            "recovery": round(recovery, 1),
        }
        self._cache[pk] = report

        # Persist the latest score so wallet lists can read it cheaply.
        if self.persistence:
            try:
                self.persistence.update_trust_score(pk, trust)
            except Exception:
                pass
        return report

    def get_trust(self, pk: str, blockchain) -> float:
        return self.report(pk, blockchain)["trust"]

    # ---------- Behaviour score (live, per-transaction) ----------

    def behaviour_score(self, tx, blockchain) -> float:
        """
        A small live risk contribution (0-25) based on the sender's very
        recent activity: how much they already have pending in the mempool
        and how many sends they've made. Rapid drain patterns score higher.
        """
        sender = tx.sender
        if not sender:
            return 0.0
        pending = [t for t in blockchain.mempool.all() if t.sender == sender]
        pending_out = sum(t.amount for t in pending)
        balance = blockchain.get_balance(sender) or 1.0

        score = 0.0
        # Draining a large fraction of balance at once is suspicious.
        drain_ratio = (pending_out + tx.amount) / (balance + tx.amount)
        score += min(15.0, drain_ratio * 15.0)
        # Many simultaneous pending sends = burst-like behaviour.
        score += min(10.0, len(pending) * 2.5)
        return round(score, 2)

    # ---------- Helpers ----------

    def _empty_report(self) -> dict:
        return {
            "trust": 100.0, "classification": "Trusted", "blacklisted": False,
            "sent_count": 0, "recv_count": 0, "mined_count": 0, "total_txs": 0,
            "high_risk_txs": 0, "med_risk_txs": 0, "clean_txs": 0,
            "penalty": 0.0, "recovery": 0.0,
        }
