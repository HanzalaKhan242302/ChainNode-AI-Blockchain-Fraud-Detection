"""
Feature Extraction for the Isolation Forest fraud model.

Each transaction gets turned into a numeric feature vector:
  [amount, sender_tx_count, sender_avg_amount, hour_of_day,
   sender_total_sent, time_since_last_tx, receiver_age]

The ML model learns the normal distribution of these features.
Statistical outliers get flagged.
"""

import time
import math


def hour_of_day(timestamp: float) -> float:
    """0-23 hour the tx was made."""
    return time.localtime(timestamp).tm_hour


def extract_features(tx, blockchain) -> list[float]:
    """
    Build a feature vector for a single transaction.
    Walks the chain history to compute behavioural stats for the sender.
    """
    sender = tx.sender
    amount = tx.amount
    ts = tx.timestamp

    # Walk chain to gather sender history
    sender_amounts = []
    last_tx_time = 0.0
    receiver_first_seen = ts

    for block in blockchain.chain:
        for past_tx in block.transactions:
            if past_tx.sender == sender and sender:
                sender_amounts.append(past_tx.amount)
                if past_tx.timestamp > last_tx_time:
                    last_tx_time = past_tx.timestamp
            if past_tx.receiver == tx.receiver and past_tx.timestamp < receiver_first_seen:
                receiver_first_seen = past_tx.timestamp

    sender_tx_count = len(sender_amounts)
    sender_avg = (sum(sender_amounts) / sender_tx_count) if sender_tx_count else 0.0
    sender_total = sum(sender_amounts)
    time_since_last = (ts - last_tx_time) if last_tx_time else 0.0
    receiver_age = ts - receiver_first_seen

    return [
        float(amount),
        float(sender_tx_count),
        float(sender_avg),
        float(hour_of_day(ts)),
        float(sender_total),
        float(time_since_last),
        float(receiver_age),
    ]


FEATURE_NAMES = [
    "amount",
    "sender_tx_count",
    "sender_avg_amount",
    "hour_of_day",
    "sender_total_sent",
    "time_since_last_tx",
    "receiver_age",
]
