"""
Fraud Detection - Layer 1: Rule-Based Filter

Fast, deterministic checks. If any rule fires, the transaction is
rejected immediately - before the ML model even runs.

Rules:
  R1: Sender is blacklisted (flagged in previous activity).
  R2: Receiver is blacklisted.
  R3: Amount exceeds the absolute maximum (sanity cap).
  R4: Burst rate - too many tx from same sender in short window.
  R5: Self-send pattern (loop attempt).
"""

import time


# Tunable constants
MAX_TX_AMOUNT       = 10_000.0   # cap any single transaction
BURST_WINDOW_SEC    = 10         # how recent counts as "burst"
BURST_MAX_TX        = 5          # >5 tx in 10s from one wallet = suspicious


class RuleEngine:
    def __init__(self, persistence=None):
        self.persistence = persistence
        self._recent: dict[str, list[float]] = {}   # sender -> list of timestamps

    def check(self, tx, blockchain) -> tuple[bool, str]:
        """
        Returns (passed, reason).
        passed=True means no rule fired.
        """
        # R1: Blacklisted sender
        if self.persistence and tx.sender:
            if self.persistence.is_flagged(tx.sender):
                return False, "sender is blacklisted"

        # R2: Blacklisted receiver
        if self.persistence:
            if self.persistence.is_flagged(tx.receiver):
                return False, "receiver is blacklisted"

        # R3: Amount cap
        if tx.amount > MAX_TX_AMOUNT:
            return False, f"amount exceeds max ({MAX_TX_AMOUNT})"

        # R4: Burst rate
        if tx.sender:
            now = time.time()
            history = self._recent.setdefault(tx.sender, [])
            history.append(now)
            # Keep only timestamps within window
            history[:] = [t for t in history if now - t <= BURST_WINDOW_SEC]
            if len(history) > BURST_MAX_TX:
                return False, f"burst rate ({len(history)} tx in {BURST_WINDOW_SEC}s)"

        # R5: Self-send (already caught earlier but defence in depth)
        if tx.sender and tx.sender == tx.receiver:
            return False, "self-send not allowed"

        return True, "ok"
