"""
Fraud Detection - Layer 2: Isolation Forest (Anomaly Detection)

How Isolation Forest works (in 3 lines):
  1. Build many random trees that split features at random.
  2. Anomalies get isolated in fewer splits (shorter path).
  3. Short avg path length → anomaly score → flag.

Lifecycle:
  - Untrained: returns score 0 (neutral), passes everything.
  - Once we have >= MIN_TRAIN_SAMPLES historical transactions,
    train the model on them.
  - Auto-retrain every RETRAIN_EVERY new transactions.
"""

import numpy as np
from sklearn.ensemble import IsolationForest
from .features import extract_features


MIN_TRAIN_SAMPLES = 20      # need at least this many tx before training
RETRAIN_EVERY     = 50      # retrain after this many new confirmed tx
CONTAMINATION     = 0.05    # expected fraction of fraud (5%)


class MLFraudModel:
    def __init__(self):
        self.model: IsolationForest | None = None
        self._tx_since_train = 0
        self.trained = False
        self.last_train_size = 0

    # ---------- Training ----------

    def train(self, blockchain) -> bool:
        """Fit Isolation Forest on all confirmed transactions in the chain."""
        samples = []
        for block in blockchain.chain:
            for tx in block.transactions:
                if not tx.sender:   # skip coinbase
                    continue
                samples.append(extract_features(tx, blockchain))

        if len(samples) < MIN_TRAIN_SAMPLES:
            return False

        X = np.array(samples)
        self.model = IsolationForest(
            n_estimators=100,
            contamination=CONTAMINATION,
            random_state=42,
        )
        self.model.fit(X)
        self.trained = True
        self.last_train_size = len(samples)
        self._tx_since_train = 0
        return True

    def maybe_retrain(self, blockchain):
        """Called after each block is mined."""
        self._tx_since_train += 1
        if not self.trained:
            self.train(blockchain)
        elif self._tx_since_train >= RETRAIN_EVERY:
            self.train(blockchain)

    # ---------- Scoring ----------

    def score(self, tx, blockchain) -> float:
        """
        Returns a risk score 0-100.
        Higher = more anomalous.
        If untrained, returns 0 (neutral).
        """
        if not self.trained or self.model is None:
            return 0.0

        features = np.array([extract_features(tx, blockchain)])
        # Isolation Forest score_samples: higher = more normal, lower = more anomalous.
        raw = self.model.score_samples(features)[0]
        # Map raw score to 0-100. Empirically: raw ranges roughly -0.7 (anomaly) to -0.4 (normal).
        # Convert: more negative → higher risk.
        risk = max(0.0, min(100.0, (-raw - 0.4) * 200))
        return round(risk, 2)

    def explain(self, tx, blockchain) -> dict:
        """
        Explain WHY a transaction got its risk score.
        Returns per-feature deviation from training mean.
        Larger deviation → bigger contribution to risk.
        """
        from .features import FEATURE_NAMES
        if not self.trained or self.model is None:
            return {"trained": False, "features": []}

        # Get this tx's features
        features = extract_features(tx, blockchain)

        # Compute training mean + std for comparison
        # (we re-extract from chain - in production, cache this)
        training = []
        for block in blockchain.chain:
            for past_tx in block.transactions:
                if not past_tx.sender:
                    continue
                training.append(extract_features(past_tx, blockchain))
        if not training:
            return {"trained": True, "features": []}

        train_arr = np.array(training)
        means = train_arr.mean(axis=0)
        stds = train_arr.std(axis=0)
        stds[stds == 0] = 1  # avoid div-by-zero

        breakdown = []
        for i, name in enumerate(FEATURE_NAMES):
            value = features[i]
            mean = means[i]
            std = stds[i]
            z = abs(value - mean) / std
            breakdown.append({
                "feature": name,
                "value": round(value, 2),
                "mean": round(float(mean), 2),
                "z_score": round(float(z), 2),
                "contribution": "high" if z > 2 else ("medium" if z > 1 else "low"),
            })
        # Sort by z_score so biggest contributors are first
        breakdown.sort(key=lambda x: x["z_score"], reverse=True)
        return {"trained": True, "features": breakdown}
