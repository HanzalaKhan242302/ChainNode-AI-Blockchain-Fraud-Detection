"""
P2P Network - Peer Registry + Gossip Broadcasting

Each node keeps a list of peer URLs (other Flask servers).
When something happens (new tx, new block), broadcast to all peers
via simple HTTP POST. Peers receive, validate, re-broadcast if novel.

This is not a real gossip protocol (no flooding control, no signatures
on messages, no eclipse-attack defence) - but it works for a LAN demo
and matches the Phase 1 scope of the report.
"""

import requests
from threading import Thread
from urllib.parse import urlparse


REQUEST_TIMEOUT = 3.0   # seconds per peer request


class PeerNetwork:
    def __init__(self, persistence, my_url: str):
        self.persistence = persistence
        self.my_url = my_url.rstrip("/")

    # ---------- Peer registry ----------

    def add_peer(self, url: str) -> bool:
        url = url.rstrip("/")
        if not url or url == self.my_url:
            return False
        # Basic URL sanity
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            return False
        self.persistence.save_peer(url)
        return True

    def get_peers(self) -> list[str]:
        return [p for p in self.persistence.list_peers() if p != self.my_url]

    def remove_peer(self, url: str):
        self.persistence.remove_peer(url.rstrip("/"))

    # ---------- Broadcasting ----------

    def _post_async(self, url: str, path: str, payload: dict):
        """Fire-and-forget POST in a thread - don't block the caller."""
        def _send():
            try:
                requests.post(url + path, json=payload, timeout=REQUEST_TIMEOUT)
            except Exception:
                pass  # silent fail - peer might be down
        Thread(target=_send, daemon=True).start()

    def broadcast_transaction(self, tx_dict: dict):
        for peer in self.get_peers():
            self._post_async(peer, "/tx/receive", tx_dict)

    def broadcast_block(self, block_dict: dict):
        for peer in self.get_peers():
            self._post_async(peer, "/block/receive", block_dict)

    def announce_self(self):
        """Tell every known peer that we exist (handshake)."""
        for peer in self.get_peers():
            self._post_async(peer, "/peers/register", {"url": self.my_url})
