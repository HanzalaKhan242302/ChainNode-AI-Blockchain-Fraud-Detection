"""
Consensus - Longest Valid Chain Rule (Nakamoto consensus).

When called, this asks every peer for their full chain. If a peer has a
chain that is:
   (a) longer than ours, and
   (b) fully valid (every block links + every PoW is real + every tx is signed)

then we replace our chain with theirs. This is how forks resolve in
a decentralised system without a central authority.
"""

import requests
from core.block import Block


REQUEST_TIMEOUT = 5.0


def resolve_conflicts(blockchain, peer_network) -> tuple[bool, str]:
    """
    Query peers, adopt longest valid chain.
    Returns (replaced, message).
    """
    longest = None
    longest_len = blockchain.length()
    source_peer = None

    for peer in peer_network.get_peers():
        try:
            r = requests.get(peer + "/chain", timeout=REQUEST_TIMEOUT)
            if r.status_code != 200:
                continue
            data = r.json()
            their_chain = data.get("chain", [])
            if len(their_chain) > longest_len:
                # Deserialise and validate
                candidate = [Block.from_dict(b) for b in their_chain]
                if blockchain.is_chain_valid(candidate):
                    longest = candidate
                    longest_len = len(candidate)
                    source_peer = peer
        except Exception:
            continue

    if longest is not None:
        blockchain.replace_chain(longest)
        return True, f"chain replaced from {source_peer} ({longest_len} blocks)"
    return False, "our chain is authoritative"
