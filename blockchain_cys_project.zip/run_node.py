"""
run_node.py - launch a single blockchain node.

Usage:
    python run_node.py --port 5001
    python run_node.py --port 5002
    python run_node.py --port 5003

Each port creates its own SQLite DB under data/node_<port>.db
so nodes don't collide on the same machine.

After starting nodes, open browser to http://127.0.0.1:5001 (etc).
Use the Peers tab in the UI to connect them to each other.
"""

import argparse
from api.app import create_app


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=5001, help="Port to run on")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host to bind")
    args = parser.parse_args()

    app = create_app(port=args.port)
    print(f"\n  ChainNode running at  http://{args.host}:{args.port}\n")
    # threaded=True so concurrent requests (peer gossip + UI polls) work
    app.run(host=args.host, port=args.port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
