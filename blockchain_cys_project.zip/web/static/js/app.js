// ChainNode - minimal client-side polish
// Live stats polling is per-page (see dashboard.html script block).
// This file holds shared niceties.

document.addEventListener('DOMContentLoaded', () => {
    // Auto-dismiss flash messages after 6s
    document.querySelectorAll('.flash').forEach((el, i) => {
        setTimeout(() => {
            el.style.transition = 'opacity 0.4s, transform 0.4s';
            el.style.opacity = '0';
            el.style.transform = 'translateY(-6px)';
            setTimeout(() => el.remove(), 400);
        }, 6000 + i * 300);
    });

    // Click-to-copy on any <code> with class "copyable"
    document.querySelectorAll('code.copyable').forEach(el => {
        el.style.cursor = 'pointer';
        el.title = 'Click to copy';
        el.addEventListener('click', () => {
            navigator.clipboard.writeText(el.textContent.trim());
            const old = el.textContent;
            el.textContent = '✓ copied';
            setTimeout(() => el.textContent = old, 900);
        });
    });
});

// Interactive Web3 Network Background
(function initWeb3Background() {
    const canvas = document.getElementById('web3-bg');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width, height, particles;

    function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    }

    class Particle {
        constructor() {
            this.x = Math.random() * width;
            this.y = Math.random() * height;
            this.vx = (Math.random() - 0.5) * 0.8;
            this.vy = (Math.random() - 0.5) * 0.8;
            this.radius = Math.random() * 3 + 2; // Made dots larger
        }
        update() {
            this.x += this.vx;
            this.y += this.vy;
            if (this.x < 0 || this.x > width) this.vx = -this.vx;
            if (this.y < 0 || this.y > height) this.vy = -this.vy;
        }
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(37, 99, 235, 0.7)'; // Much bolder blue opacity
            ctx.shadowBlur = 10;
            ctx.shadowColor = 'rgba(37, 99, 235, 0.5)'; // Add glowing effect
            ctx.fill();
            ctx.shadowBlur = 0; // Reset for lines
        }
    }

    let mouse = { x: -1000, y: -1000 };
    window.addEventListener('mousemove', e => {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
    });
    window.addEventListener('mouseout', () => {
        mouse.x = -1000;
        mouse.y = -1000;
    });

    function init() {
        resize();
        window.addEventListener('resize', resize);
        particles = [];
        const count = Math.floor((window.innerWidth * window.innerHeight) / 12000); // Slightly more particles
        for (let i = 0; i < count; i++) {
            particles.push(new Particle());
        }
        animate();
    }

    function animate() {
        ctx.clearRect(0, 0, width, height);
        
        for (let i = 0; i < particles.length; i++) {
            particles[i].update();
            particles[i].draw();
            
            // Connect to mouse
            const dxMouse = mouse.x - particles[i].x;
            const dyMouse = mouse.y - particles[i].y;
            const distMouse = Math.sqrt(dxMouse * dxMouse + dyMouse * dyMouse);
            if (distMouse < 180) {
                ctx.beginPath();
                ctx.moveTo(particles[i].x, particles[i].y);
                ctx.lineTo(mouse.x, mouse.y);
                ctx.strokeStyle = `rgba(37, 99, 235, ${0.5 - distMouse/360})`; // Bolder line to mouse
                ctx.lineWidth = 1.5;
                ctx.stroke();
                
                // Slight magnetic pull to mouse
                particles[i].x += dxMouse * 0.015;
                particles[i].y += dyMouse * 0.015;
            }

            // Connect to other particles
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 120) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.strokeStyle = `rgba(13, 148, 136, ${0.4 - dist/300})`; // Bolder teal connection
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(animate);
    }
    
    // Start after a slight delay to ensure smooth loading
    setTimeout(init, 100);
})();
