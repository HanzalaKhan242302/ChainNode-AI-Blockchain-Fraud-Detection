"""
Mempool - in-memory pool of unconfirmed transactions.

Flow:
  1. User submits a transaction → mempool.add(tx)
  2. Miner pulls transactions → mempool.pick(n)
  3. Block mined containing those tx → mempool.remove_confirmed(tx_ids)

Mempool is per-node. Each node has its own view based on what it received
through gossip. They typically converge but can diverge briefly.
"""

from threading import Lock
from .transaction import Transaction


class Mempool:
    def __init__(self, max_size: int = 1000):
        self._txs: dict[str, Transaction] = {}   # tx_id -> Transaction
        self._lock = Lock()
        self.max_size = max_size

    def add(self, tx: Transaction) -> bool:
        """Add a transaction. Returns False if already present or full."""
        with self._lock:
            if tx.tx_id in self._txs:
                return False  # duplicate
            if len(self._txs) >= self.max_size:
                return False  # full
            self._txs[tx.tx_id] = tx
            return True

    def has(self, tx_id: str) -> bool:
        with self._lock:
            return tx_id in self._txs

    def pick(self, n: int = 10) -> list[Transaction]:
        """Pick up to n transactions for mining (oldest first)."""
        with self._lock:
            items = list(self._txs.values())[:n]
        return items

    def remove_confirmed(self, tx_ids: list[str]):
        """Drop transactions that were just mined into a block."""
        with self._lock:
            for tid in tx_ids:
                self._txs.pop(tid, None)

    def all(self) -> list[Transaction]:
        with self._lock:
            return list(self._txs.values())

    def size(self) -> int:
        with self._lock:
            return len(self._txs)

    def clear(self):
        with self._lock:
            self._txs.clear()
