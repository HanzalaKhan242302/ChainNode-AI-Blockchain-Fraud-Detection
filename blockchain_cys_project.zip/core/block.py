"""
Block module.

A block is a container holding a batch of verified transactions plus
metadata that chains it to the previous block.

Structure:
    index            position in the chain (0 = genesis)
    timestamp        when this block was created
    transactions     list of Transaction objects included
    previous_hash    hash of the parent block (this is the "chain" in blockchain)
    merkle_root      single hash summarizing all transactions (tamper-evident)
    nonce            number found by miner that makes the hash valid
    difficulty       number of leading zeros required in block hash
    hash             SHA-256 of all the above

Changing ANYTHING inside a block changes its hash, which breaks the next
block's "previous_hash" link, which breaks every block after it.
"""

import json
import time
from hashlib import sha256
from .transaction import Transaction


class Block:
    def __init__(
        self,
        index: int,
        transactions: list,
        previous_hash: str,
        timestamp: float = None,
        nonce: int = 0,
        difficulty: int = 4,
        hash_: str = None,
    ):
        self.index = index
        self.transactions = transactions  # list[Transaction]
        self.previous_hash = previous_hash
        self.timestamp = timestamp if timestamp is not None else time.time()
        self.nonce = nonce
        self.difficulty = difficulty
        self.merkle_root = self._compute_merkle_root()
        self.hash = hash_ if hash_ is not None else self.compute_hash()

    # ---------- Merkle root (tx integrity inside the block) ----------

    def _compute_merkle_root(self) -> str:
        """
        Build a binary tree of hashes.
        Leaves = tx hashes. Each level = hash(left + right) until one root remains.
        Changing any single tx changes the root.
        """
        if not self.transactions:
            return sha256(b"").hexdigest()

        layer = [tx.hash() for tx in self.transactions]
        while len(layer) > 1:
            # Duplicate last if odd count (standard Bitcoin trick)
            if len(layer) % 2 == 1:
                layer.append(layer[-1])
            layer = [
                sha256((layer[i] + layer[i + 1]).encode()).hexdigest()
                for i in range(0, len(layer), 2)
            ]
        return layer[0]

    # ---------- Block hash ----------

    def _header(self) -> bytes:
        """Block header - what mining actually hashes."""
        header = {
            "index": self.index,
            "previous_hash": self.previous_hash,
            "merkle_root": self.merkle_root,
            "timestamp": self.timestamp,
            "difficulty": self.difficulty,
            "nonce": self.nonce,
        }
        return json.dumps(header, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def compute_hash(self) -> str:
        return sha256(self._header()).hexdigest()

    # ---------- Proof-of-Work ----------

    def mine(self) -> str:
        """
        Increment nonce until block hash starts with `difficulty` zeros.
        This is the lottery puzzle - only way is brute force.
        Returns final hash.
        """
        target_prefix = "0" * self.difficulty
        self.nonce = 0
        while True:
            self.hash = self.compute_hash()
            if self.hash.startswith(target_prefix):
                return self.hash
            self.nonce += 1

    def has_valid_proof(self) -> bool:
        """Check that this block's hash satisfies the difficulty target."""
        target_prefix = "0" * self.difficulty
        return self.hash.startswith(target_prefix) and self.hash == self.compute_hash()

    # ---------- Serialization ----------

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "previous_hash": self.previous_hash,
            "merkle_root": self.merkle_root,
            "nonce": self.nonce,
            "difficulty": self.difficulty,
            "hash": self.hash,
            "transactions": [tx.to_dict() for tx in self.transactions],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Block":
        txs = [Transaction.from_dict(t) for t in d.get("transactions", [])]
        return cls(
            index=d["index"],
            transactions=txs,
            previous_hash=d["previous_hash"],
            timestamp=d["timestamp"],
            nonce=d["nonce"],
            difficulty=d.get("difficulty", 4),
            hash_=d.get("hash"),
        )

    def __repr__(self):
        return (
            f"<Block #{self.index} txs={len(self.transactions)} "
            f"hash={self.hash[:10]}... prev={self.previous_hash[:10]}...>"
        )
