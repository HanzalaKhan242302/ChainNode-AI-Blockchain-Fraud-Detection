"""
Blockchain - the chain itself, plus the rules that govern it.

Responsibilities:
  - Hold the ordered list of blocks (genesis first).
  - Validate new transactions before accepting them into the mempool.
  - Validate new blocks before adding them to the chain.
  - Track balances by scanning the chain (simple account model, not UTXO).
  - Detect double-spend within the mempool + chain.
  - Provide chain replacement (longest-valid-chain consensus).

Account model note:
  Real Bitcoin uses UTXO (unspent outputs). We use a simpler account/balance
  model - easier to reason about for an academic project, and lets us cleanly
  bolt on fraud detection. Same security properties via signature checks.
"""

import time
from threading import Lock
from .block import Block
from .transaction import Transaction
from .mempool import Mempool


# Reward for mining a block (paid to the miner via a "coinbase" transaction)
MINING_REWARD = 50.0
# Initial coins each new wallet is granted - lets the demo run without faucets
INITIAL_GRANT = 100.0


class Blockchain:
    def __init__(self, difficulty: int = 4):
        self.difficulty = difficulty
        self.chain: list[Block] = []
        self.mempool = Mempool()
        # Wallets that have ever been seen - they get their initial grant once
        self._granted: set[str] = set()
        # Per-wallet initial balance {public_key_pem: float}.
        # UI-created wallets set a custom value; gossiped/auto-registered
        # wallets fall back to INITIAL_GRANT.
        self._initial_grants: dict[str, float] = {}
        # Cached balances {public_key_pem: float} - rebuilt on chain changes
        self._balances: dict[str, float] = {}
        self._lock = Lock()
        # Fraud hook: assigned externally (see fraud/risk_scorer.py)
        self.fraud_checker = None
        self._create_genesis()

    # ---------- Genesis ----------

    def _create_genesis(self):
        """First block. Has no parent, holds no real transactions."""
        genesis = Block(
            index=0,
            transactions=[],
            previous_hash="0" * 64,
            timestamp=1700000000.0,   # fixed so all nodes get identical genesis
            difficulty=self.difficulty,
        )
        genesis.nonce = 0
        genesis.hash = genesis.compute_hash()
        self.chain.append(genesis)

    # ---------- Balance tracking ----------
    # Note: helpers prefixed with _ assume the caller holds self._lock.
    # Public methods (get_balance, register_wallet) acquire it themselves.

    def get_balance(self, public_key_pem: str) -> float:
        """Compute balance: confirmed delta + starter grant."""
        with self._lock:
            return self._balances.get(public_key_pem, 0.0) + self._initial_for(pk=public_key_pem)

    def _initial_for(self, pk: str) -> float:
        """One-time starter grant - custom per wallet, else default grant."""
        if pk not in self._granted:
            return 0.0
        return self._initial_grants.get(pk, INITIAL_GRANT)

    def register_wallet(self, public_key_pem: str, initial_balance: float = None):
        """
        Mark a wallet as known so it receives its initial grant.
        If initial_balance is provided (UI wallet creation), that exact
        amount becomes the wallet's starting balance. Otherwise the default
        INITIAL_GRANT applies (used for gossiped / auto-discovered wallets).
        """
        with self._lock:
            self._register_wallet_unlocked(public_key_pem, initial_balance)

    def _register_wallet_unlocked(self, public_key_pem: str, initial_balance: float = None):
        """Lock-free version - caller must already hold self._lock."""
        self._granted.add(public_key_pem)
        if initial_balance is not None:
            self._initial_grants[public_key_pem] = float(initial_balance)
        if public_key_pem not in self._balances:
            self._balances[public_key_pem] = 0.0

    def _get_balance_unlocked(self, public_key_pem: str) -> float:
        return self._balances.get(public_key_pem, 0.0) + self._initial_for(public_key_pem)

    def _apply_tx_to_balances(self, tx: Transaction):
        """Mutate cached balances when a tx is confirmed in a block."""
        if tx.sender:   # not coinbase
            self._balances[tx.sender] = self._balances.get(tx.sender, 0.0) - tx.amount
        self._balances[tx.receiver] = self._balances.get(tx.receiver, 0.0) + tx.amount

    def _rebuild_balances(self):
        """Replay entire chain - used after chain replacement (consensus)."""
        self._rebuild_granted_and_balances()

    # ---------- Transaction acceptance ----------

    def add_transaction(self, tx: Transaction) -> tuple[bool, str]:
        """
        Validate a transaction and place it in the mempool.
        Returns (accepted, reason_or_ok).
        """
        # 1. Signature check
        if not tx.is_valid():
            return False, "invalid signature"

        # 2. Self-send check
        if tx.sender == tx.receiver:
            return False, "sender equals receiver"

        # 3. Positive amount
        if tx.amount <= 0:
            return False, "non-positive amount"

        # Auto-register parties BEFORE balance check so gossiped tx from
        # unseen wallets are still validated against the initial grant.
        if tx.sender:
            self.register_wallet(tx.sender)
        self.register_wallet(tx.receiver)

        # 4. Balance check (current balance minus already-pending spends)
        if tx.sender:
            available = self.get_balance(tx.sender) - self._pending_outflow(tx.sender)
            if available < tx.amount:
                return False, f"insufficient balance (have {available:.2f}, need {tx.amount:.2f})"

        # 5. Double-spend check (same tx_id already in mempool or chain)
        if self.mempool.has(tx.tx_id) or self._tx_in_chain(tx.tx_id):
            return False, "duplicate transaction"

        # 6. Fraud check (rules + ML, if attached)
        if self.fraud_checker is not None:
            ok, reason, score = self.fraud_checker.evaluate(tx, self)
            if not ok:
                return False, f"fraud: {reason} (risk={score})"

        # All checks passed
        self.mempool.add(tx)
        # Auto-register both parties so they show up in the system
        self.register_wallet(tx.receiver)
        if tx.sender:
            self.register_wallet(tx.sender)
        return True, "ok"

    def _pending_outflow(self, pk: str) -> float:
        """How much this wallet has already promised in mempool but not yet confirmed."""
        return sum(t.amount for t in self.mempool.all() if t.sender == pk)

    def _tx_in_chain(self, tx_id: str) -> bool:
        for block in self.chain:
            for tx in block.transactions:
                if tx.tx_id == tx_id:
                    return True
        return False

    # ---------- Mining ----------

    def mine_pending(self, miner_address: str, max_tx: int = 10) -> Block | None:
        """
        Pull transactions from mempool, build a block, mine it, add to chain.
        Pays MINING_REWARD to miner_address via a coinbase transaction.
        """
        with self._lock:
            txs = self.mempool.pick(max_tx)
            # Always add coinbase even if mempool is empty - keeps chain growing
            coinbase = Transaction(sender="", receiver=miner_address, amount=MINING_REWARD)
            block_txs = [coinbase] + txs

            new_block = Block(
                index=len(self.chain),
                transactions=block_txs,
                previous_hash=self.chain[-1].hash,
                difficulty=self.difficulty,
            )
            new_block.mine()

            # Add to chain
            self.chain.append(new_block)
            # Update balances + clear confirmed tx from mempool
            for tx in block_txs:
                self._apply_tx_to_balances(tx)
            self._register_wallet_unlocked(miner_address)
            self.mempool.remove_confirmed([t.tx_id for t in txs])
        # Outside lock - let fraud model retrain
        if self.fraud_checker is not None:
            self.fraud_checker.on_block_mined(self)
        return new_block

    # ---------- Block acceptance (from peers via gossip) ----------

    def add_block(self, block: Block) -> tuple[bool, str]:
        """
        Accept a block received from another node.
        """
        with self._lock:
            # 1. Correct index
            if block.index != len(self.chain):
                return False, f"bad index (expected {len(self.chain)}, got {block.index})"
            # 2. Links to current tip
            if block.previous_hash != self.chain[-1].hash:
                return False, "previous_hash does not match chain tip"
            # 3. Proof-of-work valid
            if not block.has_valid_proof():
                return False, "invalid proof-of-work"
            # 4. All transactions valid
            for tx in block.transactions:
                if not tx.is_valid():
                    return False, f"block contains invalid tx {tx.tx_id[:8]}"
            # 5. Merkle root matches
            if block._compute_merkle_root() != block.merkle_root:
                return False, "merkle root mismatch"

            # Accept
            self.chain.append(block)
            for tx in block.transactions:
                self._apply_tx_to_balances(tx)
                self._register_wallet_unlocked(tx.receiver)
                if tx.sender:
                    self._register_wallet_unlocked(tx.sender)
            self.mempool.remove_confirmed([t.tx_id for t in block.transactions])
        if self.fraud_checker is not None:
            self.fraud_checker.on_block_mined(self)
        return True, "ok"

    # ---------- Chain validation (full sanity check) ----------

    def is_chain_valid(self, chain: list[Block] = None) -> bool:
        """Walk the entire chain and verify every link and every proof."""
        chain = chain or self.chain
        for i in range(1, len(chain)):
            prev = chain[i - 1]
            curr = chain[i]
            if curr.previous_hash != prev.hash:
                return False
            if not curr.has_valid_proof():
                return False
            if curr._compute_merkle_root() != curr.merkle_root:
                return False
            for tx in curr.transactions:
                if not tx.is_valid():
                    return False
        return True

    # ---------- Consensus (longest valid chain wins) ----------

    def replace_chain(self, new_chain: list[Block]) -> bool:
        """
        Replace our chain with a longer valid one (Nakamoto consensus).
        Returns True if replaced.
        """
        with self._lock:
            if len(new_chain) <= len(self.chain):
                return False
            if not self.is_chain_valid(new_chain):
                return False
            self.chain = new_chain
            self._rebuild_granted_and_balances()
            return True

    def load_persisted_chain(self, persisted_chain: list[Block]):
        """
        Called on startup if a saved chain was loaded from SQLite.
        Replaces our genesis-only chain and rebuilds balance state.
        """
        with self._lock:
            if len(persisted_chain) <= 1:
                return
            self.chain = persisted_chain
            self._rebuild_granted_and_balances()

    def _rebuild_granted_and_balances(self):
        """
        Rebuild internal state from the chain.
        Every wallet that has ever appeared in the chain gets the initial grant.
        Then balances are recomputed by replaying transactions.
        """
        # Step 1: collect every wallet that ever appeared
        seen = set()
        for block in self.chain:
            for tx in block.transactions:
                if tx.sender:
                    seen.add(tx.sender)
                seen.add(tx.receiver)
        # Keep any wallet that was explicitly registered with a custom
        # initial balance, even if it hasn't transacted yet.
        seen |= set(self._initial_grants.keys())
        self._granted = seen
        # Step 2: rebuild deltas
        self._balances = {pk: 0.0 for pk in self._granted}
        for block in self.chain:
            for tx in block.transactions:
                if tx.sender:
                    self._balances[tx.sender] = self._balances.get(tx.sender, 0.0) - tx.amount
                self._balances[tx.receiver] = self._balances.get(tx.receiver, 0.0) + tx.amount

    # ---------- Inspection helpers ----------

    def length(self) -> int:
        return len(self.chain)

    def to_dict_list(self) -> list[dict]:
        return [b.to_dict() for b in self.chain]
