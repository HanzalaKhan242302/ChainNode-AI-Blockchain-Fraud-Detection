"""
Wallet module - the cryptographic identity of a user.

Each wallet holds an ECDSA (SECP256K1) keypair.
- Public key  = wallet address (shareable)
- Private key = signing key (SECRET, never leaves the wallet)

Used by:
  - Transaction.sign()    to prove ownership
  - Transaction.verify()  to confirm authenticity
"""

import os
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature


class Wallet:
    """An ECDSA SECP256K1 wallet - same curve Bitcoin uses."""

    def __init__(self, private_key=None):
        if private_key is None:
            # New wallet: generate fresh keypair
            self.private_key = ec.generate_private_key(ec.SECP256K1())
        else:
            # Load existing private key object
            self.private_key = private_key
        self.public_key = self.private_key.public_key()

    # ---------- Signing ----------

    def sign(self, message: bytes) -> bytes:
        """Sign raw bytes with private key. Returns DER-encoded signature."""
        if isinstance(message, str):
            message = message.encode("utf-8")
        return self.private_key.sign(message, ec.ECDSA(hashes.SHA256()))

    # ---------- Verification (static - anyone can call) ----------

    @staticmethod
    def verify(public_key_pem: str, message: bytes, signature: bytes) -> bool:
        """
        Verify a signature against a public key.
        Anyone in the network can call this - they only need the public key.
        """
        if isinstance(message, str):
            message = message.encode("utf-8")
        try:
            pub_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
            pub_key.verify(signature, message, ec.ECDSA(hashes.SHA256()))
            return True
        except (InvalidSignature, ValueError, Exception):
            return False

    # ---------- Serialization (for storage / network transport) ----------

    def public_key_pem(self) -> str:
        """Public key as PEM string - this IS the wallet address."""
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("utf-8")

    def private_key_pem(self, password: bytes = None) -> str:
        """Private key as PEM string - KEEP SECRET."""
        encryption = (
            serialization.BestAvailableEncryption(password)
            if password
            else serialization.NoEncryption()
        )
        return self.private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=encryption,
        ).decode("utf-8")

    @classmethod
    def from_private_pem(cls, pem_string: str, password: bytes = None) -> "Wallet":
        """Reload a wallet from a saved private key PEM."""
        priv = serialization.load_pem_private_key(
            pem_string.encode("utf-8"), password=password
        )
        return cls(private_key=priv)

    # ---------- Address (short fingerprint of public key) ----------

    def address(self) -> str:
        """
        Short human-readable address derived from public key.
        Like Bitcoin: hash the public key, take hex digest.
        """
        from hashlib import sha256
        pub_bytes = self.public_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return sha256(pub_bytes).hexdigest()[:40]  # 40-char address

    def __repr__(self):
        return f"<Wallet address={self.address()[:10]}...>"
