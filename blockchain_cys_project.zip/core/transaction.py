"""
Transaction module.

A Transaction is a signed message: "sender pays X coins to receiver."
It is the atomic unit of value transfer in the blockchain.

Lifecycle:
  1. Created with sender, receiver, amount.
  2. Signed by sender's wallet (proves ownership).
  3. Verified by any node (signature + balance check).
  4. Placed into mempool.
  5. Picked by miner, packed into a block.
  6. Block mined → transaction permanently recorded.
"""

import json
import time
import uuid
from hashlib import sha256
from .wallet import Wallet


class Transaction:
    def __init__(
        self,
        sender: str,        # sender's public key PEM ("" for coinbase / mining reward)
        receiver: str,      # receiver's public key PEM
        amount: float,
        timestamp: float = None,
        tx_id: str = None,
        signature: str = None,
        contract: dict = None,   # optional smart-contract conditions
    ):
        self.sender = sender
        self.receiver = receiver
        self.amount = float(amount)
        self.timestamp = timestamp if timestamp is not None else time.time()
        self.tx_id = tx_id if tx_id is not None else str(uuid.uuid4())
        self.signature = signature      # hex string after signing
        self.contract = contract or {}  # e.g. {"unlock_after": <epoch>}

    # ---------- Canonical bytes (what gets signed / hashed) ----------

    def _payload(self) -> bytes:
        """
        Deterministic byte representation - same across all nodes.
        Signature is NOT included (we're computing what to sign).
        """
        data = {
            "tx_id": self.tx_id,
            "sender": self.sender,
            "receiver": self.receiver,
            "amount": self.amount,
            "timestamp": self.timestamp,
            "contract": self.contract,
        }
        return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def hash(self) -> str:
        """SHA-256 fingerprint of this transaction."""
        return sha256(self._payload()).hexdigest()

    # ---------- Signing ----------

    def sign(self, wallet: Wallet):
        """Sender signs the transaction with their wallet."""
        # Safety: signer must match declared sender
        if wallet.public_key_pem().strip() != self.sender.strip():
            raise ValueError("Wallet does not match transaction sender")
        sig = wallet.sign(self._payload())
        self.signature = sig.hex()

    # ---------- Verification ----------

    def is_valid(self) -> bool:
        """
        Verify signature against sender's public key.
        Coinbase (mining reward) transactions have empty sender - allowed.
        """
        # Coinbase / system mint - sender == "" or None
        if not self.sender:
            return True
        if not self.signature:
            return False
        if self.amount <= 0:
            return False
        try:
            sig_bytes = bytes.fromhex(self.signature)
        except ValueError:
            return False
        return Wallet.verify(self.sender, self._payload(), sig_bytes)

    # ---------- Serialization ----------

    def to_dict(self) -> dict:
        return {
            "tx_id": self.tx_id,
            "sender": self.sender,
            "receiver": self.receiver,
            "amount": self.amount,
            "timestamp": self.timestamp,
            "signature": self.signature,
            "contract": self.contract,
            "hash": self.hash(),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Transaction":
        return cls(
            sender=d.get("sender", ""),
            receiver=d["receiver"],
            amount=d["amount"],
            timestamp=d.get("timestamp"),
            tx_id=d.get("tx_id"),
            signature=d.get("signature"),
            contract=d.get("contract", {}),
        )

    def __repr__(self):
        s = (self.sender[:20] + "...") if self.sender else "COINBASE"
        r = self.receiver[:20] + "..."
        return f"<Tx {self.tx_id[:8]} {s} → {r} : {self.amount}>"
