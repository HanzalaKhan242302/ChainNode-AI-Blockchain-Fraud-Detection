"""
Test suite - covers all test cases from the project report (Section 5).
Run with:  pytest tests/  -v

TC01 - Valid transaction
TC02 - Invalid signature
TC03 - Insufficient balance
TC04 - Double spending
TC05 - Fraud tracking
"""

import pytest
from core.wallet import Wallet
from core.transaction import Transaction
from core.blockchain import Blockchain
from core.block import Block
from fraud.risk_scorer import RiskScorer


# ============================================================
# Wallet tests
# ============================================================

def test_wallet_generates_keypair():
    w = Wallet()
    assert w.public_key_pem().startswith("-----BEGIN PUBLIC KEY-----")
    assert len(w.address()) == 40

def test_wallet_signature_verifies():
    w = Wallet()
    msg = b"hello blockchain"
    sig = w.sign(msg)
    assert Wallet.verify(w.public_key_pem(), msg, sig) is True

def test_wallet_wrong_signer_rejected():
    a, b = Wallet(), Wallet()
    msg = b"alice was here"
    sig_b = b.sign(msg)
    # b signed it but we try to verify with a's public key
    assert Wallet.verify(a.public_key_pem(), msg, sig_b) is False


# ============================================================
# Transaction tests
# ============================================================

def test_transaction_unsigned_invalid():
    a, b = Wallet(), Wallet()
    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 10)
    assert tx.is_valid() is False

def test_transaction_signed_valid():
    a, b = Wallet(), Wallet()
    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 10)
    tx.sign(a)
    assert tx.is_valid() is True

# TC02 - Invalid signature
def test_TC02_tampered_after_signing_invalid():
    a, b = Wallet(), Wallet()
    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 10)
    tx.sign(a)
    tx.amount = 1000  # tamper
    assert tx.is_valid() is False


# ============================================================
# Block + chain tests
# ============================================================

def test_block_mines_proof_of_work():
    a = Wallet()
    coinbase = Transaction("", a.public_key_pem(), 50)
    block = Block(index=1, transactions=[coinbase], previous_hash="0"*64, difficulty=2)
    block.mine()
    assert block.has_valid_proof()

def test_chain_validates():
    bc = Blockchain(difficulty=2)
    a, b, m = Wallet(), Wallet(), Wallet()
    bc.register_wallet(a.public_key_pem())
    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 20)
    tx.sign(a)
    bc.add_transaction(tx)
    bc.mine_pending(m.public_key_pem())
    assert bc.is_chain_valid()

# TC01 - Valid transaction
def test_TC01_valid_transaction_accepted():
    bc = Blockchain(difficulty=2)
    a, b = Wallet(), Wallet()
    bc.register_wallet(a.public_key_pem())
    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 20)
    tx.sign(a)
    ok, _ = bc.add_transaction(tx)
    assert ok is True

# TC03 - Insufficient balance
def test_TC03_insufficient_balance_rejected():
    bc = Blockchain(difficulty=2)
    a, b = Wallet(), Wallet()
    bc.register_wallet(a.public_key_pem())
    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 99999)
    tx.sign(a)
    ok, reason = bc.add_transaction(tx)
    assert ok is False
    assert "insufficient" in reason.lower()

# TC04 - Double spending (same tx_id)
def test_TC04_duplicate_transaction_rejected():
    bc = Blockchain(difficulty=2)
    a, b = Wallet(), Wallet()
    bc.register_wallet(a.public_key_pem())
    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 10)
    tx.sign(a)
    ok1, _ = bc.add_transaction(tx)
    ok2, reason = bc.add_transaction(tx)
    assert ok1 is True
    assert ok2 is False
    assert "duplicate" in reason.lower()

# TC05 - Fraud tracking
def test_TC05_fraud_blacklist_blocks_transaction():
    import core.blockchain as bm
    old = bm.INITIAL_GRANT
    bm.INITIAL_GRANT = 100000
    try:
        bc = Blockchain(difficulty=2)

        # Fake persistence with in-memory flagged set
        class FakePersistence:
            def __init__(self): self.flagged = set()
            def is_flagged(self, pk): return pk in self.flagged
            def flag_wallet(self, pk, reason): self.flagged.add(pk)

        p = FakePersistence()
        scorer = RiskScorer(persistence=p)
        bc.fraud_checker = scorer

        a, b = Wallet(), Wallet()
        bc.register_wallet(a.public_key_pem())
        p.flag_wallet(a.public_key_pem(), "test")

        tx = Transaction(a.public_key_pem(), b.public_key_pem(), 10)
        tx.sign(a)
        ok, reason = bc.add_transaction(tx)
        assert ok is False
        assert "blacklist" in reason.lower()
    finally:
        bm.INITIAL_GRANT = old


# ============================================================
# Mining produces correct balances
# ============================================================

def test_balances_after_mining():
    bc = Blockchain(difficulty=2)
    a, b, m = Wallet(), Wallet(), Wallet()
    bc.register_wallet(a.public_key_pem())

    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 30)
    tx.sign(a)
    bc.add_transaction(tx)   # auto-registers Bob as receiver
    bc.mine_pending(m.public_key_pem())

    # Alice: 100 initial - 30 sent = 70
    # Bob:   100 initial + 30 received = 130 (auto-registered)
    # Miner: 100 initial + 50 reward = 150
    assert bc.get_balance(a.public_key_pem()) == 70.0
    assert bc.get_balance(b.public_key_pem()) == 130.0
    assert bc.get_balance(m.public_key_pem()) == 150.0


# ============================================================
# Persistence (regression - balances restore correctly after reload)
# ============================================================

def test_persistence_restores_balances():
    """
    Build a chain, simulate restart by creating a new Blockchain and
    loading the chain into it, then check balances match.
    """
    bc1 = Blockchain(difficulty=2)
    a, b, m = Wallet(), Wallet(), Wallet()
    bc1.register_wallet(a.public_key_pem())

    tx = Transaction(a.public_key_pem(), b.public_key_pem(), 40)
    tx.sign(a)
    bc1.add_transaction(tx)
    bc1.mine_pending(m.public_key_pem())

    bal_a = bc1.get_balance(a.public_key_pem())
    bal_b = bc1.get_balance(b.public_key_pem())
    bal_m = bc1.get_balance(m.public_key_pem())

    # Simulate restart - new blockchain instance loads the chain
    bc2 = Blockchain(difficulty=2)
    bc2.load_persisted_chain(bc1.chain)

    assert bc2.get_balance(a.public_key_pem()) == bal_a
    assert bc2.get_balance(b.public_key_pem()) == bal_b
    assert bc2.get_balance(m.public_key_pem()) == bal_m
    assert bc2.length() == bc1.length()


# ============================================================
# Wallet import/export
# ============================================================

def test_wallet_export_and_reimport_produces_same_keypair():
    """Export private key as PEM, re-import on a "new" machine, verify same identity."""
    original = Wallet()
    pem = original.private_key_pem()
    restored = Wallet.from_private_pem(pem)

    # Public keys must match
    assert original.public_key_pem() == restored.public_key_pem()
    assert original.address() == restored.address()

    # And the restored wallet can verify the original's signatures
    msg = b"test message"
    sig = original.sign(msg)
    assert Wallet.verify(restored.public_key_pem(), msg, sig)


# ============================================================
# ML explainability (smoke test)
# ============================================================

def test_ml_explain_returns_feature_breakdown():
    from fraud.ml_model import MLFraudModel
    import core.blockchain as bm
    old = bm.INITIAL_GRANT
    bm.INITIAL_GRANT = 100000
    try:
        bc = Blockchain(difficulty=2)
        a, b, m = Wallet(), Wallet(), Wallet()
        bc.register_wallet(a.public_key_pem())

        # Need to bypass burst rule
        import fraud.rules as rules_mod
        rules_mod.BURST_MAX_TX = 10000

        scorer = RiskScorer()
        bc.fraud_checker = scorer

        # Build training history
        import random
        random.seed(7)
        for i in range(25):
            tx = Transaction(a.public_key_pem(), b.public_key_pem(),
                            round(random.uniform(5, 20), 2))
            tx.sign(a)
            bc.add_transaction(tx)
            if i % 5 == 4:
                bc.mine_pending(m.public_key_pem())

        assert scorer.ml.trained, "ML should be trained after >=20 tx"

        # Build a tx, get its explanation
        tx = Transaction(a.public_key_pem(), b.public_key_pem(), 12)
        tx.sign(a)
        explanation = scorer.explain(tx, bc)

        assert explanation["trained"] is True
        assert len(explanation["features"]) > 0
        # Each feature row has the required keys
        for f in explanation["features"]:
            assert "feature" in f
            assert "value" in f
            assert "z_score" in f
            assert "contribution" in f
    finally:
        bm.INITIAL_GRANT = old
