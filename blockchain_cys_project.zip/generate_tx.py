import requests
import os
import random
import time

PORT = 5001
BASE_URL = f"http://127.0.0.1:{PORT}"

def get_addresses():
    keys_dir = f"data/keys_{PORT}"
    addresses = []
    if os.path.exists(keys_dir):
        for f in os.listdir(keys_dir):
            if f.endswith(".pem"):
                addresses.append(f.replace(".pem", ""))
    return addresses

addresses = get_addresses()
if len(addresses) < 3:
    # create some wallets if not enough
    for i in range(3 - len(addresses)):
        requests.post(f"{BASE_URL}/wallet/create", data={"label": f"AutoWallet-{i}"})
    addresses = get_addresses()

print(f"Using addresses: {addresses}")

miner = addresses[0]

def mine_block():
    print("Mining block...")
    requests.post(f"{BASE_URL}/mine", data={"miner": miner})
    time.sleep(1)

# we need to make sure they have balance. they get 100 initially.
# we will just send 1-5 CRY back and forth.
tx_count = 0
for i in range(25): # do 25 just to be safe
    sender = random.choice(addresses)
    receiver = random.choice([a for a in addresses if a != sender])
    amount = random.randint(1, 5)
    
    resp = requests.post(f"{BASE_URL}/send", data={
        "sender": sender,
        "receiver": receiver,
        "amount": amount
    })
    print(f"Sent {amount} from {sender[:8]} to {receiver[:8]}")
    tx_count += 1
    
    if tx_count % 5 == 0:
        mine_block()

mine_block()
print("Done! AI should be trained now.")

