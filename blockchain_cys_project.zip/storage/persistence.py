"""
Persistence - bridge between in-memory Blockchain and SQLite.

Used by:
  - run_node.py        to load chain on startup, save on changes
  - api routes         to fetch labelled wallets, peer list, flagged list
"""

import json
import time
from .db import Database
from core.block import Block
from core.transaction import Transaction


class Persistence:
    def __init__(self, db: Database):
        self.db = db

    # ---------- Blocks + Transactions ----------

    def save_block(self, block: Block):
        """Persist a freshly-added block and its transactions."""
        self.db.execute(
            """INSERT OR REPLACE INTO blocks
               (idx, hash, previous_hash, merkle_root, timestamp, nonce, difficulty, tx_count)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (block.index, block.hash, block.previous_hash, block.merkle_root,
             block.timestamp, block.nonce, block.difficulty, len(block.transactions)),
        )
        for tx in block.transactions:
            self.db.execute(
                """INSERT OR REPLACE INTO transactions
                   (tx_id, block_idx, sender, receiver, amount, timestamp,
                    signature, contract, risk_score)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (tx.tx_id, block.index, tx.sender, tx.receiver, tx.amount,
                 tx.timestamp, tx.signature, json.dumps(tx.contract),
                 getattr(tx, "risk_score", 0)),
            )

    def load_chain(self) -> list[Block]:
        """Rebuild in-memory chain from DB."""
        rows = self.db.fetchall("SELECT * FROM blocks ORDER BY idx ASC")
        chain = []
        for row in rows:
            tx_rows = self.db.fetchall(
                "SELECT * FROM transactions WHERE block_idx = ? ORDER BY tx_id",
                (row["idx"],),
            )
            txs = []
            for t in tx_rows:
                tx = Transaction(
                    sender=t["sender"] or "",
                    receiver=t["receiver"],
                    amount=t["amount"],
                    timestamp=t["timestamp"],
                    tx_id=t["tx_id"],
                    signature=t["signature"],
                    contract=json.loads(t["contract"] or "{}"),
                )
                # Restore the stored risk score so fraud/analytics/trust
                # views stay accurate after a node restart.
                tx.risk_score = t["risk_score"] if t["risk_score"] is not None else 0
                txs.append(tx)
            block = Block(
                index=row["idx"],
                transactions=txs,
                previous_hash=row["previous_hash"],
                timestamp=row["timestamp"],
                nonce=row["nonce"],
                difficulty=row["difficulty"],
                hash_=row["hash"],
            )
            chain.append(block)
        return chain

    # ---------- Wallets ----------

    def save_wallet(self, public_key: str, address: str, label: str = "",
                    initial_balance: float = 100.0):
        self.db.execute(
            """INSERT OR IGNORE INTO wallets_known
               (public_key, address, label, created_at, initial_balance, trust_score)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (public_key, address, label, time.time(), float(initial_balance), 100.0),
        )

    def list_wallets(self) -> list[dict]:
        rows = self.db.fetchall("SELECT * FROM wallets_known ORDER BY created_at")
        return [dict(r) for r in rows]

    def get_wallet_by_address(self, address: str):
        row = self.db.fetchone(
            "SELECT * FROM wallets_known WHERE address = ?", (address,)
        )
        return dict(row) if row else None

    def get_wallet_by_pubkey(self, public_key: str):
        row = self.db.fetchone(
            "SELECT * FROM wallets_known WHERE public_key = ?", (public_key,)
        )
        return dict(row) if row else None

    def update_trust_score(self, public_key: str, score: float):
        self.db.execute(
            "UPDATE wallets_known SET trust_score = ? WHERE public_key = ?",
            (float(score), public_key),
        )

    def wallet_lookup_map(self) -> dict:
        """pubkey -> {label, address, initial_balance, trust_score, created_at}."""
        out = {}
        for r in self.db.fetchall("SELECT * FROM wallets_known"):
            out[r["public_key"]] = dict(r)
        return out

    # ---------- Mempool ----------

    def save_mempool_tx(self, tx: Transaction):
        self.db.execute(
            """INSERT OR IGNORE INTO mempool
               (tx_id, sender, receiver, amount, timestamp, signature, contract)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (tx.tx_id, tx.sender, tx.receiver, tx.amount, tx.timestamp,
             tx.signature, json.dumps(tx.contract)),
        )

    def remove_mempool_txs(self, tx_ids: list[str]):
        for tid in tx_ids:
            self.db.execute("DELETE FROM mempool WHERE tx_id = ?", (tid,))

    def load_mempool(self) -> list[Transaction]:
        rows = self.db.fetchall("SELECT * FROM mempool")
        return [
            Transaction(
                sender=r["sender"] or "",
                receiver=r["receiver"],
                amount=r["amount"],
                timestamp=r["timestamp"],
                tx_id=r["tx_id"],
                signature=r["signature"],
                contract=json.loads(r["contract"] or "{}"),
            )
            for r in rows
        ]

    # ---------- Peers ----------

    def save_peer(self, url: str):
        self.db.execute(
            "INSERT OR REPLACE INTO peers (url, last_seen) VALUES (?, ?)",
            (url, time.time()),
        )

    def list_peers(self) -> list[str]:
        rows = self.db.fetchall("SELECT url FROM peers")
        return [r["url"] for r in rows]

    def remove_peer(self, url: str):
        self.db.execute("DELETE FROM peers WHERE url = ?", (url,))

    # ---------- Flagged wallets ----------

    def flag_wallet(self, public_key: str, reason: str):
        self.db.execute(
            """INSERT OR REPLACE INTO flagged (public_key, reason, flagged_at)
               VALUES (?, ?, ?)""",
            (public_key, reason, time.time()),
        )

    def is_flagged(self, public_key: str) -> bool:
        row = self.db.fetchone(
            "SELECT 1 FROM flagged WHERE public_key = ?", (public_key,)
        )
        return row is not None

    def list_flagged(self) -> list[dict]:
        rows = self.db.fetchall("SELECT * FROM flagged")
        return [dict(r) for r in rows]
