"""
SQLite persistence layer.

Each node has its OWN database file (data/node_<port>.db) so multiple
nodes can run on the same machine without colliding.

Tables:
  blocks         - one row per mined block
  transactions   - one row per transaction (linked to its block)
  wallets_known  - public keys this node has seen
  peers          - other nodes we gossip with
  flagged        - wallets flagged as fraudulent
  mempool        - unconfirmed transactions (so they survive restart)
"""

import sqlite3
import json
import os
from threading import Lock


SCHEMA = """
CREATE TABLE IF NOT EXISTS blocks (
    idx          INTEGER PRIMARY KEY,
    hash         TEXT NOT NULL UNIQUE,
    previous_hash TEXT NOT NULL,
    merkle_root  TEXT NOT NULL,
    timestamp    REAL NOT NULL,
    nonce        INTEGER NOT NULL,
    difficulty   INTEGER NOT NULL,
    tx_count     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    tx_id        TEXT PRIMARY KEY,
    block_idx    INTEGER,
    sender       TEXT,
    receiver     TEXT NOT NULL,
    amount       REAL NOT NULL,
    timestamp    REAL NOT NULL,
    signature    TEXT,
    contract     TEXT,
    risk_score   REAL DEFAULT 0,
    FOREIGN KEY (block_idx) REFERENCES blocks(idx)
);

CREATE TABLE IF NOT EXISTS wallets_known (
    public_key      TEXT PRIMARY KEY,
    address         TEXT,
    label           TEXT,
    created_at      REAL,
    initial_balance REAL DEFAULT 100,
    trust_score     REAL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS peers (
    url          TEXT PRIMARY KEY,
    last_seen    REAL
);

CREATE TABLE IF NOT EXISTS flagged (
    public_key   TEXT PRIMARY KEY,
    reason       TEXT,
    flagged_at   REAL
);

CREATE TABLE IF NOT EXISTS mempool (
    tx_id        TEXT PRIMARY KEY,
    sender       TEXT,
    receiver     TEXT NOT NULL,
    amount       REAL NOT NULL,
    timestamp    REAL NOT NULL,
    signature    TEXT,
    contract     TEXT
);

CREATE INDEX IF NOT EXISTS idx_tx_block  ON transactions(block_idx);
CREATE INDEX IF NOT EXISTS idx_tx_sender ON transactions(sender);
CREATE INDEX IF NOT EXISTS idx_tx_recv   ON transactions(receiver);
"""


class Database:
    """Thread-safe SQLite wrapper."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._lock = Lock()
        # check_same_thread=False because Flask uses multiple threads
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self._migrate()

    def _migrate(self):
        """Add newer columns to DBs created by older versions (idempotent)."""
        existing = {r[1] for r in self.conn.execute("PRAGMA table_info(wallets_known)")}
        if "initial_balance" not in existing:
            self.conn.execute("ALTER TABLE wallets_known ADD COLUMN initial_balance REAL DEFAULT 100")
        if "trust_score" not in existing:
            self.conn.execute("ALTER TABLE wallets_known ADD COLUMN trust_score REAL DEFAULT 100")
        self.conn.commit()

    def execute(self, sql: str, params: tuple = ()):
        with self._lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def fetchone(self, sql: str, params: tuple = ()):
        with self._lock:
            cur = self.conn.execute(sql, params)
            return cur.fetchone()

    def fetchall(self, sql: str, params: tuple = ()):
        with self._lock:
            cur = self.conn.execute(sql, params)
            return cur.fetchall()

    def close(self):
        with self._lock:
            self.conn.close()
