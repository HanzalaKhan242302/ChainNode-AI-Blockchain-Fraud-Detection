"""
bootstrap_network.py - spin up 3 nodes for demo.

Launches 3 subprocesses (ports 5001, 5002, 5003).
Waits for them to come up, then automatically registers them
as peers of each other.

Usage:
    python bootstrap_network.py

Open browser to:
    http://127.0.0.1:5001
    http://127.0.0.1:5002
    http://127.0.0.1:5003

Press Ctrl+C to stop all nodes.
"""

import subprocess
import sys
import time
import requests
import signal
import os


PORTS = [5001, 5002, 5003]


def wait_for_node(port: int, timeout: int = 20) -> bool:
    """Poll until node responds or timeout."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = requests.get(f"http://127.0.0.1:{port}/stats", timeout=1)
            if r.status_code == 200:
                return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def register_peers():
    """Tell each node about the other two."""
    for port in PORTS:
        for peer_port in PORTS:
            if peer_port == port:
                continue
            try:
                requests.post(
                    f"http://127.0.0.1:{port}/peers/register",
                    json={"url": f"http://127.0.0.1:{peer_port}"},
                    timeout=2,
                )
            except Exception as e:
                print(f"  warning: could not register {peer_port} on {port}: {e}")


def main():
    procs = []
    print("Launching nodes...")
    for port in PORTS:
        # Suppress flask noise to stdout but keep stderr
        p = subprocess.Popen(
            [sys.executable, "run_node.py", "--port", str(port)],
            stdout=subprocess.DEVNULL,
        )
        procs.append((port, p))
        print(f"  node {port} pid={p.pid}")

    print("\nWaiting for nodes to come up...")
    for port, _ in procs:
        if wait_for_node(port):
            print(f"  ✓ node {port} ready")
        else:
            print(f"  ✗ node {port} did not start")

    print("\nRegistering peers...")
    register_peers()
    print("\n" + "=" * 60)
    print("  Network is up. Open in your browser:")
    for port in PORTS:
        print(f"      http://127.0.0.1:{port}")
    print("=" * 60)
    print("\nPress Ctrl+C to stop all nodes.\n")

    def shutdown(*_):
        print("\nShutting down...")
        for port, p in procs:
            p.terminate()
        for port, p in procs:
            try:
                p.wait(timeout=5)
            except Exception:
                p.kill()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # Idle loop
    while True:
        time.sleep(1)


if __name__ == "__main__":
    main()
