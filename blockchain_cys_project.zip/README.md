# ChainNode — Blockchain Transaction System

**Air University · Cryptography Final Project**

A real working multi-node blockchain with cryptographic transactions, proof-of-work mining, AI fraud detection, persistence, analytics dashboard, and explainable ML. Not a simulation — every component is genuinely functional.

---

## Team

- Syed Ahtsham Hussain Shah — 242364
- Huzaifah Bin Naeem — 242298
- Ahmed Najam — 242320
- Hanzala Khan — 242302

Supervisor: Ms. Maila Zahra

---

## What it does

### Core blockchain
- **Generates real ECDSA wallets** (SECP256K1 — the curve Bitcoin uses)
- **Signs transactions** with private keys, verifies with public keys
- **Hashes blocks** with SHA-256, links them via previous-hash
- **Mines blocks** with real Proof-of-Work (find a nonce so hash starts with N zeros)
- **Builds a Merkle tree** of transactions inside each block
- **Persists everything** to SQLite — chain + balances survive restart

### Fraud detection (two-layer engine)
- **Layer 1 — Rules**: signature, blacklist, amount cap, burst-rate, double-spend
- **Layer 2 — Isolation Forest ML**: trained on confirmed transactions, scores anomalies 0–100
- **Explainable** — click any flagged transaction to see WHY (per-feature Z-score breakdown)

### P2P Network
- Multiple nodes gossip transactions and blocks over HTTP
- **Longest-valid-chain consensus** resolves forks
- **Peer health monitoring** — `/api/peer_health` pings all peers

### Wallet management
- **Create wallets** — fresh ECDSA keypair stored locally
- **Export private key** — download `.pem` file for backup
- **Import wallet** — restore from `.pem` on any node
- **Per-wallet transaction history** — see every transaction involving a wallet

### Dashboard & UI
- **Live dashboard** — auto-refreshes every 3 seconds
- **Analytics page** — 5 charts: cumulative tx, tx per block, volume, risk distribution, nonce trend
- **Explorer** — browse every block, expand to see transactions, Merkle root, nonce
- **API documentation page** — every endpoint listed

---

## Setup

Requires **Python 3.11+**.

```bash
# 1. Install dependencies
pip install -r requirements.txt
pip install pytest

# 2. Run tests (16 should pass)
pytest tests/ -v
```

---

## Run

### Single node

```bash
python run_node.py --port 5001
```

Open browser to `http://127.0.0.1:5001`.

### Multi-node network (3 nodes)

```bash
python bootstrap_network.py
```

This launches 3 nodes (ports 5001, 5002, 5003) and auto-connects them as peers.

Press **Ctrl+C** to stop all nodes.

---

## Walkthrough — try it yourself

1. Open `http://127.0.0.1:5001` → **Wallets** tab → create wallets *Alice*, *Bob*, *Miner*.
2. Click any wallet card → see its detail page + transaction history + export key.
3. Go to **Send** → Alice → Bob → 25 → *Sign & Broadcast*.
4. Open `http://127.0.0.1:5002` → mempool shows 1 pending (gossiped).
5. Back on node 1 → **Mine** tab → pick Miner → *Start Mining*.
6. All nodes now show chain length 2.
7. Open **Analytics** tab — charts populate.
8. Open **Explorer** to inspect block details.
9. Open **API** tab to see every endpoint documented.

### Test persistence
- Press Ctrl+C to stop nodes
- Restart: `python bootstrap_network.py`
- Chain length, wallets, balances all restored ✅

### Test fraud detection
- Send amount 15000 → red flash: "amount exceeds max" (Layer 1 rule)
- Build up 20+ valid tx → ML trains automatically
- Click any flagged tx on Fraud page → see feature-level explanation

---

## Architecture

```
core/           cryptographic engine (wallet, transaction, block, blockchain, mempool)
fraud/          two-layer fraud detection (rules + Isolation Forest + explain)
network/        P2P gossip + consensus
storage/        SQLite persistence
api/            Flask routes + server factory
web/            Jinja templates (8 pages) + CSS + JS
tests/          pytest suite (16 tests covering TC01–TC05 + extras)
data/           per-node SQLite databases + private key storage
```

### Pages

| Page | Purpose |
|---|---|
| **Dashboard** | Live stats with auto-refresh |
| **Wallets** | Create / import / export wallets |
| **Wallet Detail** | Per-wallet transaction history |
| **Send** | Sign & broadcast transactions |
| **Mine** | Trigger Proof-of-Work mining |
| **Explorer** | Browse every block in chain |
| **Fraud** | Detection engine status + click-to-explain |
| **Analytics** | 5 live charts (Chart.js) |
| **Peers** | P2P peer management + sync |
| **API** | Endpoint documentation |

---

## How fraud detection works (your novelty)

**Layer 1 — Rule-based (instant):**
Signature, blacklist, amount cap (10,000), burst rate (5 tx / 10s), self-send.

**Layer 2 — Isolation Forest ML:**
Each transaction → 7-feature vector:
`[amount, sender_tx_count, sender_avg_amount, hour_of_day, sender_total_sent, time_since_last_tx, receiver_age]`

Model trains on confirmed tx (>=20), retrains every 50 new tx. Outputs risk score 0–100.

**Explainability:**
For any flagged transaction, the `/api/explain/<tx_id>` endpoint returns per-feature deviation (Z-score) from training mean. Shows WHICH features contributed to the flag.

**Decision policy:**
- ≥ 75 → REJECT + blacklist sender
- 40–75 → ACCEPT but flag for review
- < 40 → clean

---

## Test cases (from report Section 5)

| ID | Description | Status |
|---|---|---|
| TC01 | Valid transaction | ✅ pass |
| TC02 | Invalid / tampered signature | ✅ pass |
| TC03 | Insufficient balance | ✅ pass |
| TC04 | Double spending | ✅ pass |
| TC05 | Fraud blacklist tracking | ✅ pass |

Plus 11 additional tests (16 total): wallet generation, mining PoW, chain validation, persistence restore, wallet import/export, ML explanation.

Run: `pytest tests/ -v`

---

## REST API endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/stats` | Node status JSON |
| GET | `/chain` | Full chain |
| GET | `/mempool` | Pending transactions |
| GET | `/api/analytics` | Time-series for charts |
| GET | `/api/explain/<tx_id>` | ML feature breakdown |
| GET | `/api/peer_health` | Peer reachability |
| POST | `/tx/receive` | Gossip endpoint |
| POST | `/block/receive` | Block broadcast endpoint |
| POST | `/peers/register` | Add peer URL |
| GET | `/wallet/export/<addr>` | Download private key PEM |
| POST | `/wallet/import` | Restore from uploaded PEM |

Full reference: open `http://127.0.0.1:5001/api/docs` in browser.

---

## Tech stack

| Layer | Tech |
|---|---|
| Language | Python 3.11+ |
| Cryptography | `cryptography` library — ECDSA SECP256K1 + SHA-256 |
| Web server | Flask |
| ML | scikit-learn — Isolation Forest + Z-score explainability |
| Persistence | SQLite (per-node) |
| P2P transport | HTTP + `requests` |
| Frontend | Jinja2 + vanilla CSS/JS, Chart.js for charts |
| Fonts | JetBrains Mono + Space Grotesk |
| Tests | pytest |

---

## Why this is a real blockchain (not a simulation)

| Check | This project |
|---|---|
| Each block hash actually computed via SHA-256? | ✅ yes |
| Each block links to previous via `previous_hash`? | ✅ yes |
| Tampering breaks the chain (hash mismatch)? | ✅ yes |
| Private keys are real ECDSA? | ✅ yes |
| Signatures actually verified before accepting tx? | ✅ yes |
| Mining requires real CPU work (brute-force nonce)? | ✅ yes |
| Multiple nodes run independently and gossip? | ✅ yes |
| Network can resolve forks via longest valid chain? | ✅ yes |
| State persists across restarts? | ✅ yes |

---

## Known limitations (honest)

- Difficulty fixed at 3 — fast for demo, not real Bitcoin-level security
- Account/balance model rather than UTXO — simpler, easier to explain
- Initial 100-CRY grant per wallet — so demo isn't empty
- No transaction fees — would add for "real" deployment
- No network encryption — peers use HTTP, fine for localhost
- Smart contracts are scoped out — future work

---

## License

Academic project — Air University. Free for educational use.

## Enhancements (v2)

Five features were added on top of the base node, modifying the existing
Flask/blockchain architecture (no rewrite):

1. **Real-Time Analytics Dashboard** (`/analytics`) — live overview cards,
   growth chart, interactive wallet-network graph, fraud heat-map, risk
   distribution, live mining panel, pending-tx feed and tx-frequency charts,
   all driven by `GET /api/analytics` and refreshed every 5 s.
2. **Custom Wallet Initial Balance** — wallet creation takes a validated
   positive starting balance (stored in `wallets_known.initial_balance` and
   used everywhere the balance is shown / spent). Hardcoded default removed.
3. **Improved Transaction History** — Explorer and history tables resolve
   public keys to `Name (0xHASH…)`, with amount, risk, trust, timestamp and
   tx id; parties are clickable.
4. **Wallet Details Page** (`/wallet/<address>`) — full profile: info,
   reputation (trust bar), statistics, searchable/sortable history, a
   counterparty graph, an activity timeline, export/copy actions and a QR code.
5. **Wallet Trust Engine** (`fraud/trust_engine.py`) — dynamic 0–100 wallet
   reputation. Final risk = ML risk + trust penalty + behaviour score, so the
   fraud decision no longer relies on the ML score alone.

Note: the genesis block is now persisted, fixing a latent bug where chain
history was dropped on node restart.
