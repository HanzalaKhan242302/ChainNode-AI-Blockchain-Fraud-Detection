import requests
import os
import random
import time

PORT = 5001
BASE_URL = f"http://127.0.0.1:{PORT}"

def get_addresses():
    keys_dir = f"data/keys_{PORT}"
    addresses = []
    if os.path.exists(keys_dir):
        for f in os.listdir(keys_dir):
            if f.endswith(".pem"):
                addresses.append(f.replace(".pem", ""))
    return addresses

addresses = get_addresses()
miner = addresses[0]

print("Generating 10 slow transactions to avoid burst rate limits...")
tx_count = 0
for i in range(10):
    sender = random.choice(addresses)
    receiver = random.choice([a for a in addresses if a != sender])
    amount = random.randint(1, 3)
    
    resp = requests.post(f"{BASE_URL}/send", data={
        "sender": sender,
        "receiver": receiver,
        "amount": amount
    })
    
    if "success" in resp.text.lower() or resp.status_code in [200, 302]:
        print(f"Sent {amount} from {sender[:8]} to {receiver[:8]}")
    else:
        print(f"Failed to send: {resp.text[:50]}")
        
    tx_count += 1
    
    # Sleep to avoid burst rate (5 tx / 10 sec)
    time.sleep(2.5)
    
    if tx_count % 5 == 0:
        print("Mining block...")
        requests.post(f"{BASE_URL}/mine", data={"miner": miner})
        time.sleep(1)

print("Mining final block...")
requests.post(f"{BASE_URL}/mine", data={"miner": miner})

