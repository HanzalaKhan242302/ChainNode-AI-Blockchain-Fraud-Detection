"""
Flask Application - REST API + Web UI server.

Every node runs an instance of this app on its own port.
Routes are grouped:
    /                       - Web UI pages (Jinja templates)
    /wallet/*               - Wallet management
    /tx/*                   - Transactions
    /chain, /block/*        - Chain inspection
    /mine                   - Trigger mining
    /peers/*                - P2P registration
    /fraud/*                - Fraud stats + flagged wallets
"""

import os
import time
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash

from core.wallet import Wallet
from core.transaction import Transaction
from core.block import Block
from core.blockchain import Blockchain, MINING_REWARD
from storage.db import Database
from storage.persistence import Persistence
from fraud.risk_scorer import RiskScorer
from network.peer import PeerNetwork
from network.consensus import resolve_conflicts


from hashlib import sha256 as _sha256


def wallet_short_hash(pem: str) -> str:
    """A stable, short 0x-prefixed display hash for any public key PEM."""
    if not pem:
        return "0xCOINBASE"
    return "0x" + _sha256(pem.encode("utf-8")).hexdigest()[:8].upper()


def resolve_party(pem: str, wmap: dict) -> dict:
    """
    Turn a raw public-key PEM into display info.
    Returns {name, hash, address, known, is_coinbase, pem}.
    wmap = pubkey -> wallet row dict (from persistence.wallet_lookup_map()).
    """
    if not pem:
        return {"name": "COINBASE", "hash": "0xCOINBASE", "address": None,
                "known": False, "is_coinbase": True, "pem": ""}
    row = wmap.get(pem)
    if row:
        return {"name": row.get("label") or "untitled",
                "hash": wallet_short_hash(pem),
                "address": row.get("address"),
                "known": True, "is_coinbase": False, "pem": pem}
    return {"name": None, "hash": wallet_short_hash(pem), "address": None,
            "known": False, "is_coinbase": False, "pem": pem}


def _build_network_graph(blockchain, persistence, scorer, wmap, focus_pem=None):
    """
    Build a wallet-network graph.
      nodes: wallets (id = short hash). size ~ tx volume, colour ~ trust.
      edges: aggregated sender->receiver transfers (weight = total amount).
    If focus_pem is set, restrict to that wallet and its direct counterparties.
    """
    volume = {}          # pem -> total value moved
    edges_map = {}       # (src_pem, dst_pem) -> {weight, count}
    neighbours = set()

    for block in blockchain.chain:
        for tx in block.transactions:
            if not tx.sender:      # skip coinbase edges (no real source node)
                continue
            src, dst = tx.sender, tx.receiver
            if focus_pem and focus_pem not in (src, dst):
                continue
            if focus_pem:
                neighbours.add(src); neighbours.add(dst)
            volume[src] = volume.get(src, 0.0) + tx.amount
            volume[dst] = volume.get(dst, 0.0) + tx.amount
            key = (src, dst)
            e = edges_map.setdefault(key, {"weight": 0.0, "count": 0})
            e["weight"] += tx.amount
            e["count"] += 1

    # Node universe
    node_pems = set(volume.keys())
    if not focus_pem:
        # include known wallets even with no tx yet
        for pem in wmap.keys():
            node_pems.add(pem)
    else:
        node_pems = neighbours

    nodes = []
    for pem in node_pems:
        if not pem:
            continue
        row = wmap.get(pem)
        rep = scorer.wallet_report(pem, blockchain)
        nodes.append({
            "id": wallet_short_hash(pem),
            "label": (row.get("label") if row else None) or wallet_short_hash(pem),
            "address": row.get("address") if row else None,
            "trust": rep["trust"],
            "blacklisted": rep["blacklisted"],
            "volume": round(volume.get(pem, 0.0), 2),
            "balance": round(blockchain.get_balance(pem), 2),
            "is_focus": (pem == focus_pem),
        })

    edges = []
    for (src, dst), e in edges_map.items():
        edges.append({
            "source": wallet_short_hash(src),
            "target": wallet_short_hash(dst),
            "weight": round(e["weight"], 2),
            "count": e["count"],
        })

    return {"nodes": nodes, "edges": edges}


def create_app(port: int, data_dir: str = "data") -> Flask:
    """
    Build a fully wired Flask app for one node.
    Each node is identified by its port.
    """
    # Resolve dirs
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_dir = os.path.join(base_dir, "web", "templates")
    static_dir = os.path.join(base_dir, "web", "static")
    db_path = os.path.join(base_dir, data_dir, f"node_{port}.db")

    app = Flask(
        __name__,
        template_folder=template_dir,
        static_folder=static_dir,
    )
    app.secret_key = f"node-{port}-secret"

    # ---------- Wire up node state ----------

    db = Database(db_path)
    persistence = Persistence(db)
    blockchain = Blockchain(difficulty=3)
    scorer = RiskScorer(persistence=persistence)
    blockchain.fraud_checker = scorer
    my_url = f"http://127.0.0.1:{port}"
    network = PeerNetwork(persistence, my_url)

    # Ensure the (deterministic) genesis block is persisted. Older runs only
    # saved mined blocks, which left the reloaded chain missing block #0 and
    # silently discarded chain history on restart. Genesis is deterministic,
    # so re-saving it is idempotent and keeps previous_hash links intact.
    persistence.save_block(blockchain.chain[0])

    # Load any existing chain + mempool from previous runs
    saved_chain = persistence.load_chain()
    if len(saved_chain) > 1:
        blockchain.load_persisted_chain(saved_chain)
    # Re-register every known wallet with its stored custom initial balance
    # so balances are correct even for wallets that never transacted.
    for w in persistence.list_wallets():
        blockchain.register_wallet(
            w["public_key"],
            initial_balance=w.get("initial_balance", 100.0),
        )
    for tx in persistence.load_mempool():
        if tx.is_valid():
            blockchain.mempool.add(tx)

    # Stash on app for routes
    app.config["NODE"] = {
        "port": port,
        "url": my_url,
        "blockchain": blockchain,
        "persistence": persistence,
        "scorer": scorer,
        "network": network,
    }

    # ============================================================
    # Web UI Pages
    # ============================================================

    @app.route("/")
    def dashboard():
        bc = app.config["NODE"]["blockchain"]
        recent_blocks = list(reversed(bc.chain[-5:]))
        scorer = app.config["NODE"]["scorer"]
        return render_template(
            "dashboard.html",
            node_url=my_url,
            port=port,
            chain_length=bc.length(),
            mempool_size=bc.mempool.size(),
            peer_count=len(network.get_peers()),
            recent_blocks=recent_blocks,
            fraud_stats=scorer.stats(),
            difficulty=bc.difficulty,
        )

    @app.route("/wallet")
    def wallet_page():
        wallets = persistence.list_wallets()
        # Attach balance + trust to each
        for w in wallets:
            w["balance"] = blockchain.get_balance(w["public_key"])
            report = scorer.wallet_report(w["public_key"], blockchain)
            w["trust"] = report["trust"]
            w["trust_class"] = report["classification"]
            w["hash"] = wallet_short_hash(w["public_key"])
        return render_template("wallet.html", wallets=wallets, port=port)

    @app.route("/wallet/create", methods=["POST"])
    def wallet_create():
        label = request.form.get("label", "").strip() or f"Wallet-{int(time.time())}"
        # ---- Custom initial balance (validated) ----
        raw_balance = request.form.get("initial_balance", "").strip()
        if raw_balance == "":
            flash("Initial balance is required", "error")
            return redirect(url_for("wallet_page"))
        try:
            initial_balance = float(raw_balance)
        except ValueError:
            flash("Initial balance must be a number", "error")
            return redirect(url_for("wallet_page"))
        if initial_balance < 0:
            flash("Initial balance cannot be negative", "error")
            return redirect(url_for("wallet_page"))

        w = Wallet()
        pem = w.public_key_pem()
        addr = w.address()
        persistence.save_wallet(pem, addr, label, initial_balance=initial_balance)
        blockchain.register_wallet(pem, initial_balance=initial_balance)
        # Save private key to local node-secure file (NOT shared with peers)
        priv_dir = os.path.join(base_dir, "data", f"keys_{port}")
        os.makedirs(priv_dir, exist_ok=True)
        with open(os.path.join(priv_dir, f"{addr}.pem"), "w") as f:
            f.write(w.private_key_pem())
        flash(f"Wallet '{label}' created with balance {initial_balance:.2f} CRY (addr {addr[:16]}...)", "success")
        return redirect(url_for("wallet_page"))

    @app.route("/wallet/export/<address>")
    def wallet_export(address):
        """Download the private key file so user can back it up."""
        from flask import send_file, abort
        priv_path = os.path.join(base_dir, "data", f"keys_{port}", f"{address}.pem")
        if not os.path.exists(priv_path):
            abort(404)
        return send_file(priv_path, as_attachment=True,
                         download_name=f"wallet_{address[:8]}.pem",
                         mimetype="application/x-pem-file")

    @app.route("/wallet/import", methods=["POST"])
    def wallet_import():
        """Restore a wallet from a previously-exported PEM file."""
        label = request.form.get("label", "").strip() or f"Imported-{int(time.time())}"
        pem_file = request.files.get("keyfile")
        if not pem_file:
            flash("No file provided", "error")
            return redirect(url_for("wallet_page"))
        pem_text = pem_file.read().decode("utf-8")
        try:
            w = Wallet.from_private_pem(pem_text)
        except Exception as e:
            flash(f"Invalid key file: {e}", "error")
            return redirect(url_for("wallet_page"))
        pem = w.public_key_pem()
        addr = w.address()
        persistence.save_wallet(pem, addr, label)
        blockchain.register_wallet(pem)
        priv_dir = os.path.join(base_dir, "data", f"keys_{port}")
        os.makedirs(priv_dir, exist_ok=True)
        with open(os.path.join(priv_dir, f"{addr}.pem"), "w") as f:
            f.write(pem_text)
        flash(f"Wallet '{label}' imported. Balance: {blockchain.get_balance(pem):.2f}", "success")
        return redirect(url_for("wallet_page"))

    @app.route("/wallet/<address>")
    def wallet_detail(address):
        """Per-wallet page: full profile, statistics, history, graph, timeline."""
        row = persistence.get_wallet_by_address(address)
        if not row:
            return "Wallet not found", 404
        pem = row["public_key"]
        wmap = persistence.wallet_lookup_map()

        history = []
        total_sent = 0.0
        total_received = 0.0
        total_mined = 0.0
        blocks_mined = 0
        amounts = []
        counterparties = {}   # pem -> {name, hash, address, incoming, outgoing, count}
        timeline = []
        first_ts = None
        last_ts = None

        for block in blockchain.chain:
            for tx in block.transactions:
                if tx.sender != pem and tx.receiver != pem:
                    continue
                is_coinbase = not tx.sender
                if is_coinbase and tx.receiver == pem:
                    direction = "MINED"
                    other_pem = ""
                    total_mined += tx.amount
                    blocks_mined += 1
                elif tx.sender == pem:
                    direction = "OUT"
                    other_pem = tx.receiver
                    total_sent += tx.amount
                    amounts.append(tx.amount)
                else:
                    direction = "IN"
                    other_pem = tx.sender
                    total_received += tx.amount
                    amounts.append(tx.amount)

                party = resolve_party(other_pem, wmap)
                risk = getattr(tx, "risk_score", 0) or 0
                history.append({
                    "block": block.index,
                    "tx_id": tx.tx_id,
                    "direction": direction,
                    "other_name": party["name"],
                    "other_hash": party["hash"],
                    "other_address": party["address"],
                    "amount": tx.amount,
                    "timestamp": tx.timestamp,
                    "risk": risk,
                })

                # counterparties (skip coinbase source)
                if not is_coinbase:
                    cp = counterparties.setdefault(other_pem, {
                        "name": party["name"], "hash": party["hash"],
                        "address": party["address"], "incoming": 0.0,
                        "outgoing": 0.0, "count": 0,
                    })
                    cp["count"] += 1
                    if direction == "OUT":
                        cp["outgoing"] += tx.amount
                    else:
                        cp["incoming"] += tx.amount

                # timeline events
                if direction == "MINED":
                    timeline.append({"ts": tx.timestamp,
                                     "label": f"Mined Block #{block.index}",
                                     "kind": "mine"})
                elif direction == "IN":
                    timeline.append({"ts": tx.timestamp,
                                     "label": f"Received {tx.amount:.0f} CRY",
                                     "kind": "in"})
                else:
                    timeline.append({"ts": tx.timestamp,
                                     "label": f"Sent {tx.amount:.0f} CRY",
                                     "kind": "out"})

                first_ts = tx.timestamp if first_ts is None else min(first_ts, tx.timestamp)
                last_ts = tx.timestamp if last_ts is None else max(last_ts, tx.timestamp)

        history.reverse()   # newest first
        timeline.sort(key=lambda e: e["ts"])   # oldest first for the flow

        # Prepend wallet-created event, append flag event if blacklisted
        created_at = row.get("created_at") or (first_ts or time.time())
        timeline.insert(0, {"ts": created_at, "label": "Created Wallet", "kind": "create"})

        trust_report = scorer.wallet_report(pem, blockchain)
        if trust_report["blacklisted"]:
            timeline.append({"ts": last_ts or created_at,
                             "label": "Flagged for Review", "kind": "flag"})

        total_tx = len([h for h in history if h["direction"] != "MINED"])
        stats = {
            "total_tx": total_tx,
            "total_sent": total_sent,
            "total_received": total_received,
            "total_mined": total_mined,
            "blocks_mined": blocks_mined,
            "avg_amount": (sum(amounts) / len(amounts)) if amounts else 0.0,
            "largest": max(amounts) if amounts else 0.0,
            "smallest": min(amounts) if amounts else 0.0,
            "last_ts": last_ts,
            "first_ts": first_ts,
            "created_at": created_at,
        }

        counterparty_list = sorted(
            counterparties.values(), key=lambda c: c["count"], reverse=True
        )

        return render_template(
            "wallet_detail.html",
            wallet=row,
            wallet_hash=wallet_short_hash(pem),
            balance=blockchain.get_balance(pem),
            history=history,
            stats=stats,
            trust=trust_report,
            counterparties=counterparty_list,
            timeline=timeline,
            now=time.time(),
            port=port,
        )

    @app.route("/send")
    def send_page():
        wallets = persistence.list_wallets()
        for w in wallets:
            w["balance"] = blockchain.get_balance(w["public_key"])
        return render_template("send.html", wallets=wallets, port=port)

    @app.route("/send", methods=["POST"])
    def send_submit():
        sender_addr = request.form["sender"]
        receiver_addr = request.form["receiver"]
        amount = float(request.form["amount"])

        sender_row = persistence.get_wallet_by_address(sender_addr)
        receiver_row = persistence.get_wallet_by_address(receiver_addr)
        if not sender_row or not receiver_row:
            flash("Invalid sender or receiver address", "error")
            return redirect(url_for("send_page"))

        # Load sender's private key
        priv_path = os.path.join(base_dir, "data", f"keys_{port}", f"{sender_addr}.pem")
        if not os.path.exists(priv_path):
            flash("Private key for sender not found on this node", "error")
            return redirect(url_for("send_page"))
        with open(priv_path) as f:
            sender_wallet = Wallet.from_private_pem(f.read())

        tx = Transaction(sender_row["public_key"], receiver_row["public_key"], amount)
        tx.sign(sender_wallet)
        ok, reason = blockchain.add_transaction(tx)
        if ok:
            persistence.save_mempool_tx(tx)
            network.broadcast_transaction(tx.to_dict())
            flash(f"Transaction broadcast! ID: {tx.tx_id[:12]}... (risk: {getattr(tx,'risk_score',0)})", "success")
        else:
            flash(f"Rejected: {reason}", "error")
        return redirect(url_for("send_page"))

    @app.route("/explorer")
    def explorer_page():
        wmap = persistence.wallet_lookup_map()
        blocks_view = []
        for block in reversed(blockchain.chain):
            txs = []
            for tx in block.transactions:
                sender = resolve_party(tx.sender, wmap)
                receiver = resolve_party(tx.receiver, wmap)
                s_trust = (scorer.wallet_report(tx.sender, blockchain)["trust"]
                           if tx.sender else None)
                txs.append({
                    "tx_id": tx.tx_id,
                    "sender": sender,
                    "receiver": receiver,
                    "amount": tx.amount,
                    "risk": getattr(tx, "risk_score", 0) or 0,
                    "timestamp": tx.timestamp,
                    "sender_trust": s_trust,
                })
            blocks_view.append({
                "index": block.index,
                "hash": block.hash,
                "previous_hash": block.previous_hash,
                "merkle_root": block.merkle_root,
                "nonce": block.nonce,
                "difficulty": block.difficulty,
                "timestamp": block.timestamp,
                "transactions": txs,
            })
        return render_template("explorer.html", chain=blocks_view, port=port)

    @app.route("/mining")
    def mining_page():
        wallets = persistence.list_wallets()
        return render_template(
            "mining.html",
            wallets=wallets,
            mempool=blockchain.mempool.all(),
            mempool_size=blockchain.mempool.size(),
            port=port,
        )

    @app.route("/mine", methods=["POST"])
    def mine_submit():
        miner_addr = request.form.get("miner")
        if not miner_addr:
            flash("Pick a miner wallet", "error")
            return redirect(url_for("mining_page"))
        row = persistence.get_wallet_by_address(miner_addr)
        if not row:
            flash("Unknown miner address", "error")
            return redirect(url_for("mining_page"))
        block = blockchain.mine_pending(row["public_key"])
        persistence.save_block(block)
        persistence.remove_mempool_txs([t.tx_id for t in block.transactions])
        network.broadcast_block(block.to_dict())
        flash(f"Mined block #{block.index} (nonce={block.nonce}, {len(block.transactions)} tx)", "success")
        return redirect(url_for("mining_page"))

    @app.route("/fraud")
    def fraud_page():
        flagged = persistence.list_flagged()
        # Build list of recent flagged tx from chain
        flagged_tx = []
        for block in reversed(blockchain.chain):
            for tx in block.transactions:
                if getattr(tx, "risk_score", 0) and tx.risk_score >= 40:
                    flagged_tx.append({
                        "tx_id": tx.tx_id,
                        "sender": tx.sender[:30] + "..." if tx.sender else "COINBASE",
                        "receiver": tx.receiver[:30] + "...",
                        "amount": tx.amount,
                        "risk": tx.risk_score,
                        "block": block.index,
                    })
                    if len(flagged_tx) >= 20:
                        break
        return render_template(
            "fraud.html",
            stats=scorer.stats(),
            flagged_wallets=flagged,
            flagged_tx=flagged_tx,
            port=port,
        )

    @app.route("/peers")
    def peers_page():
        return render_template(
            "peers.html",
            peers=network.get_peers(),
            my_url=my_url,
            port=port,
        )

    @app.route("/peers/add", methods=["POST"])
    def peers_add():
        url = request.form.get("url", "").strip()
        if network.add_peer(url):
            network.announce_self()
            flash(f"Peer added: {url}", "success")
        else:
            flash("Invalid peer URL", "error")
        return redirect(url_for("peers_page"))

    @app.route("/peers/sync", methods=["POST"])
    def peers_sync():
        replaced, msg = resolve_conflicts(blockchain, network)
        if replaced:
            # Persist the whole new chain
            for block in blockchain.chain:
                persistence.save_block(block)
        flash(msg, "success" if replaced else "info")
        return redirect(url_for("peers_page"))

    @app.route("/api/docs")
    def api_docs_page():
        return render_template("api_docs.html", port=port)

    @app.route("/analytics")
    def analytics_page():
        return render_template("analytics.html", port=port)

    # ============================================================
    # JSON API (used by peers + JS polling)
    # ============================================================

    @app.route("/chain")
    def api_chain():
        return jsonify({"length": blockchain.length(), "chain": blockchain.to_dict_list()})

    @app.route("/mempool")
    def api_mempool():
        return jsonify({"count": blockchain.mempool.size(),
                        "transactions": [t.to_dict() for t in blockchain.mempool.all()]})

    @app.route("/stats")
    def api_stats():
        return jsonify({
            "port": port,
            "chain_length": blockchain.length(),
            "mempool_size": blockchain.mempool.size(),
            "peer_count": len(network.get_peers()),
            "fraud": scorer.stats(),
            "difficulty": blockchain.difficulty,
        })

    @app.route("/api/analytics")
    def api_analytics():
        """All time-series + aggregate data for the real-time dashboard."""
        import time as _t
        wmap = persistence.wallet_lookup_map()

        # ---- Block-by-block series ----
        blocks_series = []
        cumulative_tx = 0
        risk_values = []
        total_mining_rewards = 0.0
        for block in blockchain.chain:
            user_tx = sum(1 for tx in block.transactions if tx.sender)
            cumulative_tx += user_tx
            blocks_series.append({
                "index": block.index,
                "tx_count": user_tx,
                "cumulative_tx": cumulative_tx,
                "cumulative_blocks": block.index + 1,
                "nonce": block.nonce,
                "timestamp": block.timestamp,
            })
            for tx in block.transactions:
                if not tx.sender:
                    total_mining_rewards += tx.amount
                else:
                    risk_values.append(getattr(tx, "risk_score", 0) or 0)

        tx_volume = [
            {"block": b.index,
             "volume": sum(tx.amount for tx in b.transactions if tx.sender)}
            for b in blockchain.chain
        ]

        # ---- Risk distribution ----
        risk_buckets = {"low (<40)": 0, "medium (40-75)": 0, "high (>=75)": 0}
        safe = medium = high = 0
        for r in risk_values:
            if r >= 75:
                risk_buckets["high (>=75)"] += 1; high += 1
            elif r >= 40:
                risk_buckets["medium (40-75)"] += 1; medium += 1
            else:
                risk_buckets["low (<40)"] += 1; safe += 1

        # ---- Fraud heatmap (risk >= 40) by day-of-week x hour ----
        heat = [[0] * 24 for _ in range(7)]
        by_hour = [0] * 24
        by_day = [0] * 7
        for block in blockchain.chain:
            for tx in block.transactions:
                if not tx.sender:
                    continue
                if (getattr(tx, "risk_score", 0) or 0) < 40:
                    continue
                lt = _t.localtime(tx.timestamp)
                heat[lt.tm_wday][lt.tm_hour] += 1
                by_hour[lt.tm_hour] += 1
                by_day[lt.tm_wday] += 1

        # ---- Transaction frequency (per minute / per hour) ----
        now = _t.time()
        per_minute = [{"label": f"-{29 - i}m", "count": 0} for i in range(30)]
        per_hour = [{"label": f"-{23 - i}h", "count": 0} for i in range(24)]
        for block in blockchain.chain:
            for tx in block.transactions:
                if not tx.sender:
                    continue
                age = now - tx.timestamp
                if 0 <= age < 30 * 60:
                    per_minute[29 - int(age // 60)]["count"] += 1
                if 0 <= age < 24 * 3600:
                    per_hour[23 - int(age // 3600)]["count"] += 1

        # ---- Mining panel ----
        last = blockchain.chain[-1]
        avg_nonce = (sum(b.nonce for b in blockchain.chain) / len(blockchain.chain)) if blockchain.chain else 0
        mining = {
            "difficulty": blockchain.difficulty,
            "last_nonce": last.nonce,
            "avg_nonce": round(avg_nonce, 1),
            "reward": MINING_REWARD,
            "last_block_index": last.index,
            "last_block_hash": last.hash,
            "last_block_time": last.timestamp,
        }

        # ---- Pending transactions ----
        pending = []
        for tx in blockchain.mempool.all():
            s = resolve_party(tx.sender, wmap)
            r = resolve_party(tx.receiver, wmap)
            pending.append({
                "tx_id": tx.tx_id,
                "sender_name": s["name"], "sender_hash": s["hash"],
                "receiver_name": r["name"], "receiver_hash": r["hash"],
                "amount": tx.amount,
                "timestamp": tx.timestamp,
                "risk": getattr(tx, "risk_score", 0) or 0,
            })

        # ---- Overview cards ----
        wallets = persistence.list_wallets()
        blacklisted = 0
        for w in wallets:
            rep = scorer.wallet_report(w["public_key"], blockchain)
            if rep["blacklisted"]:
                blacklisted += 1
        avg_risk = round(sum(risk_values) / len(risk_values), 1) if risk_values else 0.0

        total_user_tx = len(risk_values)
        clean = safe
        clean_ratio = (clean / total_user_tx) if total_user_tx else 1.0
        health = 100.0 * clean_ratio
        health -= min(20, blockchain.mempool.size())          # backlog penalty
        health -= blacklisted * 5                             # bad actors penalty
        health = round(max(0.0, min(100.0, health)), 1)

        overview = {
            "total_blocks": blockchain.length(),
            "total_transactions": total_user_tx,
            "total_wallets": len(wallets),
            "total_mining_rewards": round(total_mining_rewards, 2),
            "pending_transactions": blockchain.mempool.size(),
            "blacklisted_wallets": blacklisted,
            "avg_risk_score": avg_risk,
            "health_score": health,
        }

        return jsonify({
            "overview": overview,
            "blocks_series": blocks_series,
            "tx_volume": tx_volume,
            "risk_buckets": risk_buckets,
            "risk_distribution": {"safe": safe, "medium": medium, "high": high},
            "fraud_heatmap": {"matrix": heat, "by_hour": by_hour, "by_day": by_day},
            "mining": mining,
            "pending": pending,
            "frequency": {"per_minute": per_minute, "per_hour": per_hour},
            "network_graph": _build_network_graph(blockchain, persistence, scorer, wmap),
            "fraud_stats": scorer.stats(),
        })

    @app.route("/api/network_graph")
    def api_network_graph():
        wmap = persistence.wallet_lookup_map()
        return jsonify(_build_network_graph(blockchain, persistence, scorer, wmap))

    @app.route("/api/wallet_graph/<address>")
    def api_wallet_graph(address):
        row = persistence.get_wallet_by_address(address)
        if not row:
            return jsonify({"error": "not found"}), 404
        wmap = persistence.wallet_lookup_map()
        return jsonify(_build_network_graph(blockchain, persistence, scorer, wmap,
                                            focus_pem=row["public_key"]))

    @app.route("/api/explain/<tx_id>")
    def api_explain_tx(tx_id):
        """Return ML feature breakdown for a transaction in the chain."""
        for block in blockchain.chain:
            for tx in block.transactions:
                if tx.tx_id == tx_id:
                    breakdown = scorer.explain(tx, blockchain)
                    return jsonify({
                        "tx_id": tx_id,
                        "risk_score": getattr(tx, "risk_score", 0),
                        "explanation": breakdown,
                    })
        return jsonify({"error": "tx not found"}), 404

    @app.route("/api/peer_health")
    def api_peer_health():
        """Check which peers are reachable right now."""
        import requests as rq
        peers = network.get_peers()
        results = []
        for peer in peers:
            try:
                r = rq.get(peer + "/stats", timeout=1.5)
                results.append({
                    "url": peer,
                    "online": r.status_code == 200,
                    "chain_length": r.json().get("chain_length") if r.status_code == 200 else None,
                })
            except Exception:
                results.append({"url": peer, "online": False, "chain_length": None})
        return jsonify({"peers": results})

    @app.route("/tx/receive", methods=["POST"])
    def api_tx_receive():
        """Peer gossiped a transaction to us."""
        data = request.get_json()
        if not data:
            return jsonify({"ok": False, "reason": "no data"}), 400
        tx = Transaction.from_dict(data)
        if blockchain.mempool.has(tx.tx_id):
            return jsonify({"ok": True, "reason": "already have it"})
        ok, reason = blockchain.add_transaction(tx)
        if ok:
            persistence.save_mempool_tx(tx)
            # Re-broadcast so the news spreads
            network.broadcast_transaction(tx.to_dict())
        return jsonify({"ok": ok, "reason": reason})

    @app.route("/block/receive", methods=["POST"])
    def api_block_receive():
        """Peer gossiped a newly-mined block."""
        data = request.get_json()
        if not data:
            return jsonify({"ok": False, "reason": "no data"}), 400
        block = Block.from_dict(data)
        # If it builds on our tip, accept directly
        if block.index == blockchain.length() and block.previous_hash == blockchain.chain[-1].hash:
            ok, reason = blockchain.add_block(block)
            if ok:
                persistence.save_block(block)
                persistence.remove_mempool_txs([t.tx_id for t in block.transactions])
                network.broadcast_block(block.to_dict())
            return jsonify({"ok": ok, "reason": reason})
        # Otherwise we may be behind - try to sync from peers
        if block.index >= blockchain.length():
            replaced, msg = resolve_conflicts(blockchain, network)
            if replaced:
                for b in blockchain.chain:
                    persistence.save_block(b)
                return jsonify({"ok": True, "reason": f"synced: {msg}"})
        return jsonify({"ok": False, "reason": "block does not extend our chain"})

    @app.route("/peers/register", methods=["POST"])
    def api_peers_register():
        data = request.get_json()
        if not data or "url" not in data:
            return jsonify({"ok": False}), 400
        network.add_peer(data["url"])
        return jsonify({"ok": True, "peers": network.get_peers()})

    @app.route("/peers/list")
    def api_peers_list():
        return jsonify({"peers": network.get_peers(), "self": my_url})

    return app
